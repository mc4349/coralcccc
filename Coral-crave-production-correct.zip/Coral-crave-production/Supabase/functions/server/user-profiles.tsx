import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Get user profile
app.get('/make-server-9f7745d8/users/:userId/profile', async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log('Getting user profile:', userId);

    const profile = await kv.get(`user_profile_${userId}`);
    
    if (!profile?.value) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    // Get additional profile data
    const reviews = await kv.getByPrefix(`user_review_${userId}_`);
    const listings = await kv.getByPrefix(`user_listing_${userId}_`);
    const followers = await kv.get(`user_followers_${userId}`);
    const following = await kv.get(`user_following_${userId}`);

    const profileData = {
      ...profile.value,
      reviewCount: reviews.length,
      listingCount: listings.length,
      followerCount: followers?.value?.length || 0,
      followingCount: following?.value?.length || 0
    };

    return c.json(profileData);

  } catch (error) {
    console.error('Get profile error:', error);
    return c.json({ error: 'Failed to get profile' }, 500);
  }
});

// Update user profile
app.put('/make-server-9f7745d8/users/:userId/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');
    
    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const updateData = await c.req.json();
    console.log('Updating user profile:', userId, updateData);

    const existingProfile = await kv.get(`user_profile_${userId}`);
    const profile = {
      ...(existingProfile?.value || {}),
      ...updateData,
      id: userId,
      lastUpdated: new Date().toISOString()
    };

    await kv.set(`user_profile_${userId}`, profile);

    return c.json({ success: true, profile });

  } catch (error) {
    console.error('Update profile error:', error);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Follow/unfollow user
app.post('/make-server-9f7745d8/users/:userId/follow', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const targetUserId = c.req.param('userId');
    
    if (user.id === targetUserId) {
      return c.json({ error: 'Cannot follow yourself' }, 400);
    }

    console.log('Follow action:', user.id, 'target:', targetUserId);

    // Get current following list for the user
    const userFollowing = await kv.get(`user_following_${user.id}`);
    const following = userFollowing?.value || [];

    // Get current followers list for the target user
    const targetFollowers = await kv.get(`user_followers_${targetUserId}`);
    const followers = targetFollowers?.value || [];

    const isFollowing = following.includes(targetUserId);

    if (isFollowing) {
      // Unfollow
      const newFollowing = following.filter((id: string) => id !== targetUserId);
      const newFollowers = followers.filter((id: string) => id !== user.id);
      
      await kv.set(`user_following_${user.id}`, newFollowing);
      await kv.set(`user_followers_${targetUserId}`, newFollowers);
    } else {
      // Follow
      const newFollowing = [...following, targetUserId];
      const newFollowers = [...followers, user.id];
      
      await kv.set(`user_following_${user.id}`, newFollowing);
      await kv.set(`user_followers_${targetUserId}`, newFollowers);
    }

    return c.json({ 
      success: true, 
      isFollowing: !isFollowing,
      followerCount: isFollowing ? followers.length - 1 : followers.length + 1
    });

  } catch (error) {
    console.error('Follow error:', error);
    return c.json({ error: 'Failed to follow/unfollow user' }, 500);
  }
});

// Get user reviews
app.get('/make-server-9f7745d8/users/:userId/reviews', async (c) => {
  try {
    const userId = c.req.param('userId');
    const type = c.req.query('type') || 'all'; // buyer, seller, all
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '10');

    console.log('Getting user reviews:', userId, type);

    const userReviews = await kv.getByPrefix(`user_review_${userId}_`);
    let reviews = userReviews.map(review => review.value).filter(review => review && typeof review === 'object');

    // Filter by type
    if (type !== 'all') {
      reviews = reviews.filter(review => review.type === type);
    }

    // Sort by date (newest first)
    reviews.sort((a, b) => new Date(b.date || 0).getTime() - new Date(a.date || 0).getTime());

    // Paginate
    const startIndex = (page - 1) * limit;
    const paginatedReviews = reviews.slice(startIndex, startIndex + limit);

    return c.json({
      reviews: paginatedReviews,
      totalCount: reviews.length,
      page,
      limit,
      totalPages: Math.ceil(reviews.length / limit)
    });

  } catch (error) {
    console.error('Get reviews error:', error);
    return c.json({ error: 'Failed to get reviews' }, 500);
  }
});

// Create review for user
app.post('/make-server-9f7745d8/users/:userId/reviews', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const targetUserId = c.req.param('userId');
    const { rating, comment, type, itemTitle, itemId } = await c.req.json();

    if (user.id === targetUserId) {
      return c.json({ error: 'Cannot review yourself' }, 400);
    }

    if (rating < 1 || rating > 5) {
      return c.json({ error: 'Rating must be between 1 and 5' }, 400);
    }

    console.log('Creating review:', user.id, 'for:', targetUserId, rating);

    const reviewId = `review_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const review = {
      id: reviewId,
      reviewerId: user.id,
      reviewerName: user.user_metadata?.name || user.email,
      reviewerAvatar: user.user_metadata?.avatar_url,
      rating,
      comment,
      type, // 'buyer' or 'seller'
      itemTitle,
      itemId,
      date: new Date().toISOString()
    };

    await kv.set(`user_review_${targetUserId}_${reviewId}`, review);

    // Update user's overall rating
    const userProfile = await kv.get(`user_profile_${targetUserId}`);
    if (userProfile?.value) {
      const currentRating = userProfile.value.rating || 0;
      const currentCount = userProfile.value.totalRatings || 0;
      const newTotalRating = (currentRating * currentCount) + rating;
      const newCount = currentCount + 1;
      const newAvgRating = newTotalRating / newCount;

      userProfile.value.rating = newAvgRating;
      userProfile.value.totalRatings = newCount;
      
      await kv.set(`user_profile_${targetUserId}`, userProfile.value);
    }

    return c.json({ success: true, review });

  } catch (error) {
    console.error('Create review error:', error);
    return c.json({ error: 'Failed to create review' }, 500);
  }
});

// Get user's listings
app.get('/make-server-9f7745d8/users/:userId/listings', async (c) => {
  try {
    const userId = c.req.param('userId');
    const status = c.req.query('status') || 'all'; // active, sold, ended, all
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');

    console.log('Getting user listings:', userId, status);

    const userListings = await kv.getByPrefix(`user_listing_${userId}_`);
    let listings = userListings.map(listing => listing.value).filter(listing => listing && typeof listing === 'object');

    // Filter by status
    if (status !== 'all') {
      listings = listings.filter(listing => listing.status === status);
    }

    // Sort by date (newest first)
    listings.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

    // Paginate
    const startIndex = (page - 1) * limit;
    const paginatedListings = listings.slice(startIndex, startIndex + limit);

    return c.json({
      listings: paginatedListings,
      totalCount: listings.length,
      page,
      limit,
      totalPages: Math.ceil(listings.length / limit)
    });

  } catch (error) {
    console.error('Get listings error:', error);
    return c.json({ error: 'Failed to get listings' }, 500);
  }
});

// Get user verification status
app.get('/make-server-9f7745d8/users/:userId/verification', async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log('Getting verification status:', userId);

    const verification = await kv.get(`user_verification_${userId}`);
    
    return c.json({
      verified: verification?.value?.verified || false,
      verificationLevel: verification?.value?.level || 'none',
      badges: verification?.value?.badges || [],
      verificationDate: verification?.value?.verificationDate
    });

  } catch (error) {
    console.error('Get verification error:', error);
    return c.json({ error: 'Failed to get verification status' }, 500);
  }
});

// Request verification
app.post('/make-server-9f7745d8/users/:userId/verification/request', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');
    
    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const { documents, businessType, experience } = await c.req.json();
    
    console.log('Verification request:', userId, businessType);

    const verificationRequest = {
      userId,
      status: 'pending',
      requestDate: new Date().toISOString(),
      documents,
      businessType,
      experience,
      reviewedBy: null,
      reviewDate: null
    };

    await kv.set(`verification_request_${userId}`, verificationRequest);

    return c.json({ success: true, message: 'Verification request submitted' });

  } catch (error) {
    console.error('Request verification error:', error);
    return c.json({ error: 'Failed to submit verification request' }, 500);
  }
});

// Get user stats for profile
app.get('/make-server-9f7745d8/users/:userId/stats', async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log('Getting user stats:', userId);

    // Get various metrics
    const listings = await kv.getByPrefix(`user_listing_${userId}_`);
    const reviews = await kv.getByPrefix(`user_review_${userId}_`);
    const sales = listings.filter(l => l.value?.status === 'sold');
    
    const totalRevenue = sales.reduce((sum, sale) => sum + (sale.value?.finalPrice || 0), 0);
    const avgSalePrice = sales.length > 0 ? totalRevenue / sales.length : 0;
    
    const successRate = listings.length > 0 ? (sales.length / listings.length) * 100 : 0;
    
    const avgRating = reviews.length > 0 
      ? reviews.reduce((sum, review) => sum + (review.value?.rating || 0), 0) / reviews.length 
      : 0;

    const stats = {
      totalListings: listings.length,
      totalSales: sales.length,
      totalRevenue,
      avgSalePrice,
      successRate,
      avgRating,
      totalReviews: reviews.length,
      joinDate: new Date().toISOString(), // Would come from user registration
      responseTime: '< 2 hours', // Could be calculated from messages
      avgShippingTime: '1-2 days' // Could be calculated from orders
    };

    return c.json(stats);

  } catch (error) {
    console.error('Get user stats error:', error);
    return c.json({ error: 'Failed to get user stats' }, 500);
  }
});

export default app;