import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Video, VideoOff, Users, MessageCircle, X, Settings, Gavel, Clock, DollarSign, Plus } from 'lucide-react';
import { AGORA_CONFIG, loadAgoraSDK, createAgoraClient } from '../utils/agora-config';
import { AuctionQueue } from './AuctionQueue';
import { DemoBiddingPanel } from './DemoBiddingPanel';
import { PinnedLotCard } from './PinnedLotCard';
import { StreamRoleManager } from './StreamRoleManager';

interface AgoraLiveStreamProps {
  channelName: string;
  isHost: boolean;
  onLeave: () => void;
  userToken?: string;
  forceRealCamera?: boolean; // Optional - defaults to true for real camera experience
}

interface AgoraRTCClient {
  join: (appId: string, channel: string, token: string | null, uid?: string | number | null) => Promise<string | number>;
  leave: () => Promise<void>;
  publish: (tracks: any[]) => Promise<void>;
  unpublish: (tracks?: any[]) => Promise<void>;
  on: (event: string, callback: (...args: any[]) => void) => void;
  off: (event: string, callback: (...args: any[]) => void) => void;
}

declare global {
  interface Window {
    AgoraRTC: {
      createClient: (config: { mode: string; codec: string }) => AgoraRTCClient;
      createMicrophoneAudioTrack: () => Promise<any>;
      createCameraVideoTrack: () => Promise<any>;
    };
  }
}

export function AgoraLiveStream({ channelName, isHost, onLeave, userToken, forceRealCamera = true }: AgoraLiveStreamProps) {
  const [client, setClient] = useState<AgoraRTCClient | null>(null);
  const [localAudioTrack, setLocalAudioTrack] = useState<any>(null);
  const [localVideoTrack, setLocalVideoTrack] = useState<any>(null);
  const [remoteUsers, setRemoteUsers] = useState<any[]>([]);
  const [micEnabled, setMicEnabled] = useState(true);
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [viewerCount, setViewerCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isEmbeddedMode, setIsEmbeddedMode] = useState(false);
  const [simulatedVideo, setSimulatedVideo] = useState(false);
  
  // Permission handling states
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [permissionStep, setPermissionStep] = useState<'request' | 'denied' | 'granted'>('request');
  const [permissionError, setPermissionError] = useState<string | null>(null);
  
  // Chat state
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  
  // Auction state
  const [currentAuctionItem, setCurrentAuctionItem] = useState<any>(null);
  const [upcomingItems, setUpcomingItems] = useState<any[]>([]);
  const [showAuctionQueue, setShowAuctionQueue] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [winningItem, setWinningItem] = useState<any>(null);
  
  // Add new item modal state
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [newItemForm, setNewItemForm] = useState({
    title: '',
    description: '',
    startingBid: '',
    timer: '300' // 5 minutes default
  });

  const localVideoRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Check permissions helper
  const checkMediaPermissions = async () => {
    try {
      const permissions = await navigator.permissions.query({ name: 'camera' as PermissionName });
      const micPermissions = await navigator.permissions.query({ name: 'microphone' as PermissionName });
      
      return {
        camera: permissions.state,
        microphone: micPermissions.state
      };
    } catch (error) {
      // Fallback for browsers that don't support permissions API
      console.warn('Permissions API not supported, will request directly');
      return null;
    }
  };

  // Request permissions with user guidance
  const requestMediaPermissions = async () => {
    try {
      console.log('🔐 Requesting media permissions...');
      
      // First, check if we're in an iframe with restrictive permissions policy
      try {
        // Test if camera permission is even possible in this environment
        const permissions = await navigator.permissions.query({ name: 'camera' as PermissionName });
        console.log('🔍 Camera permission state:', permissions.state);
      } catch (permissionsApiError) {
        console.warn('⚠️ Permissions API not available or restricted:', permissionsApiError);
      }
      
      // Check if permissions are already granted
      const permissionStatus = await checkMediaPermissions();
      
      if (permissionStatus?.camera === 'granted' && permissionStatus?.microphone === 'granted') {
        console.log('✅ Permissions already granted');
        setPermissionStep('granted');
        return true;
      }
      
      // For real camera mode, be much more persistent about getting permissions
      if (forceRealCamera) {
        console.log('🔐 Real camera mode - attempting to request permissions...');
        
        // First, try a quick test to see if getUserMedia is even allowed
        try {
          console.log('🔍 Testing if getUserMedia is allowed in this environment...');
          const testStream = await navigator.mediaDevices.getUserMedia({ 
            video: { width: 1, height: 1 }, 
            audio: false 
          });
          testStream.getTracks().forEach(track => track.stop());
          console.log('✅ getUserMedia is allowed in this environment');
        } catch (testError) {
          console.warn('❌ getUserMedia test failed:', testError);
          
          // Check for specific iframe/permissions policy violations
          if (testError.message?.includes('not allowed') || 
              testError.message?.includes('policy') ||
              testError.message?.includes('Permission denied')) {
            console.error('🚫 Detected iframe permissions policy restriction');
            throw new Error('Camera access is blocked by browser security policy in this embedded environment. This is a limitation of the iframe sandbox. Real camera streaming is not available in this preview mode.');
          }
        }
        
        // Try multiple approaches to get permissions
        for (let attempt = 1; attempt <= 3; attempt++) {
          console.log(`🔐 Permission attempt ${attempt}/3`);
          
          try {
            // Use a more explicit permission request with better constraints
            const stream = await navigator.mediaDevices.getUserMedia({ 
              video: {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                frameRate: { ideal: 30 }
              }, 
              audio: {
                echoCancellation: true,
                noiseSuppression: true
              }
            });
            
            // Successfully got permissions!
            console.log('✅ Media permissions granted on attempt', attempt);
            
            // Close the stream immediately (we'll create proper tracks later)
            stream.getTracks().forEach(track => track.stop());
            
            setPermissionStep('granted');
            return true;
            
          } catch (directError) {
            console.warn(`🔐 Attempt ${attempt} failed:`, directError.message);
            
            // Check for iframe permission policy violations
            if (directError.message?.includes('not allowed') || 
                directError.message?.includes('policy') ||
                (directError.name === 'NotAllowedError' && attempt === 1)) {
              console.error('🚫 Detected iframe permissions policy restriction on attempt', attempt);
              throw new Error('Camera access is blocked by browser security policy in this embedded environment. This is a limitation of the iframe sandbox where this preview is running. Real camera streaming is not available in preview mode.');
            }
            
            if (attempt === 3) {
              // On final attempt, show helpful modal
              console.log('🔐 All direct attempts failed, showing guided modal');
              
              setShowPermissionModal(true);
              setPermissionStep('request');
              
              // Wait for user to proceed via modal with more detailed guidance
              return new Promise<boolean>((resolve) => {
                const handlePermissionRequest = async () => {
                  try {
                    console.log('🔐 User requesting permissions via modal...');
                    
                    // Try with maximum compatibility settings
                    const stream = await navigator.mediaDevices.getUserMedia({ 
                      video: true, 
                      audio: true 
                    });
                    
                    // Close the stream immediately
                    stream.getTracks().forEach(track => track.stop());
                    
                    console.log('✅ Media permissions granted via modal');
                    setPermissionStep('granted');
                    setShowPermissionModal(false);
                    resolve(true);
                  } catch (error) {
                    console.error('❌ Permission denied via modal:', error);
                    setPermissionStep('denied');
                    setPermissionError(error.message || 'Permission denied');
                    
                    // Check for iframe restrictions in modal too
                    if (error.message?.includes('not allowed') || error.message?.includes('policy')) {
                      setPermissionError('Camera access is blocked by browser security policy in this embedded environment. This is a limitation of preview mode.');
                      
                      // Show iframe-specific troubleshooting
                      alert(`Camera access blocked by iframe security policy.

This preview environment runs in a secure iframe that blocks camera access for security reasons.

To test real camera streaming:
1. Deploy this application to a real domain (not in iframe)
2. Access it directly in your browser (not embedded)
3. Camera permissions will work normally there

This is a limitation of the preview environment, not the application itself.`);
                    } else {
                      // Show standard troubleshooting
                      alert(`Camera/microphone access denied. 

Troubleshooting steps:
1. Look for a camera/microphone icon in your browser's address bar
2. Click it and select "Allow" 
3. Make sure you're on HTTPS (not HTTP)
4. Try refreshing the page
5. Check your browser settings under Privacy & Security

Error: ${error.message}`);
                    }
                    
                    resolve(false);
                  }
                };
                
                // Store the handler so we can call it from the modal
                (window as any).handlePermissionRequest = handlePermissionRequest;
                
                // Show immediate browser permission dialog
                setTimeout(() => {
                  (window as any).handlePermissionRequest();
                }, 500);
                
                // Auto-timeout after 60 seconds (longer for troubleshooting)
                setTimeout(() => {
                  if (permissionStep === 'request') {
                    console.warn('⏰ Permission request timed out after 60 seconds');
                    setPermissionStep('denied');
                    setPermissionError('Permission request timed out - this may be due to iframe security restrictions');
                    setShowPermissionModal(false);
                    resolve(false);
                  }
                }, 60000);
              });
            } else {
              // Wait before retrying
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
          }
        }
      } else {
        // In demo mode, skip permission request
        console.log('🎭 Demo mode - skipping permission request');
        return true;
      }
    } catch (error) {
      console.error('Permission request failed:', error);
      setPermissionError(error.message || 'Failed to request permissions');
      return false;
    }
  };

  const handleSendMessage = () => {
    if (!currentMessage.trim()) return;

    const newMessage = {
      id: Date.now().toString(),
      user: { name: 'You', color: '#FBBF24' },
      message: currentMessage,
      timestamp: new Date().toISOString(),
      type: 'message'
    };

    setChatMessages(prev => [...prev, newMessage]);
    setCurrentMessage('');

    // Scroll to bottom
    if (chatContainerRef.current) {
      setTimeout(() => {
        chatContainerRef.current?.scrollTo({ top: chatContainerRef.current.scrollHeight, behavior: 'smooth' });
      }, 100);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleBid = (amount: number) => {
    console.log('🎯 Bid placed:', amount);
    // In a real implementation, this would update the auction state
    if (currentAuctionItem) {
      setCurrentAuctionItem(prev => ({
        ...prev,
        currentBid: amount,
        bidCount: prev.bidCount + 1,
        highestBidder: 'You'
      }));
      
      // Add a chat message about the bid
      const bidMessage = {
        id: Date.now().toString(),
        user: { name: 'System', color: '#10B981' },
        message: `💰 New bid placed: $${amount} by You`,
        timestamp: new Date().toISOString(),
        type: 'bid'
      };
      setChatMessages(prev => [...prev, bidMessage]);
      
      // Auto-scroll chat to show the new bid
      if (chatContainerRef.current) {
        setTimeout(() => {
          chatContainerRef.current?.scrollTo({ top: chatContainerRef.current.scrollHeight, behavior: 'smooth' });
        }, 100);
      }
    }
  };

  const handleAuthRequired = () => {
    console.log('🔐 Authentication required for bidding');
  };

  const handleStartAuction = (item: any) => {
    console.log('🎯 Starting auction for:', item);
    setCurrentAuctionItem(item);
    setShowAuctionQueue(false);
  };

  const handleAddItem = () => {
    // Validate form
    if (!newItemForm.title.trim() || !newItemForm.startingBid || parseFloat(newItemForm.startingBid) <= 0) {
      alert('Please fill in all required fields with valid values');
      return;
    }

    const newItem = {
      id: `item_${Date.now()}`,
      title: newItemForm.title,
      description: newItemForm.description,
      startingBid: parseFloat(newItemForm.startingBid),
      currentBid: parseFloat(newItemForm.startingBid),
      bidCount: 0,
      timer: parseInt(newItemForm.timer),
      image: 'https://images.unsplash.com/photo-1522802451138-8afd417be4bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmFsJTIwcmVlZiUyMGFxdWFyaXVtfGVufDF8fHx8MTc1ODA0ODMwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      sellerId: userToken || 'demo-seller',
      sellerName: 'Demo Seller'
    };

    setUpcomingItems(prev => [...prev, newItem]);
    
    // Reset form
    setNewItemForm({
      title: '',
      description: '',
      startingBid: '',
      timer: '300'
    });
    
    setShowAddItemModal(false);
    
    console.log('✅ Added new item to queue:', newItem);
  };

  const getDummyUser = () => ({
    id: userToken || 'demo-user',
    email: 'demo@coralcrave.com',
    name: 'Demo User'
  });

  useEffect(() => {
    console.log('🎥 Initializing Agora LiveStream:', {
      channelName,
      isHost,
      userToken
    });
    
    // Initialize demo data first
    initializeDemoData();
    
    // Load Agora SDK and initialize
    loadAgoraSDK()
      .then(() => initializeAgora())
      .catch((error) => {
        console.error('Failed to load Agora SDK:', error);
        setError('Failed to load Agora SDK');
      });

    return () => {
      cleanup();
    };
  }, []);

  // Separate function to initialize demo data
  const initializeDemoData = () => {
    // Initialize chat messages
    setChatMessages([
      {
        id: '1',
        user: { name: 'ReefExplorer', color: '#10B981' },
        message: 'Amazing coral collection!',
        timestamp: new Date().toISOString(),
        type: 'message'
      },
      {
        id: '2',
        user: { name: 'CoralFan123', color: '#3B82F6' },
        message: 'Beautiful colors on that one!',
        timestamp: new Date().toISOString(),
        type: 'message'
      }
    ]);

    // Initialize auction items
    setCurrentAuctionItem({
      id: 'auction_1',
      title: 'Premium Rainbow Acropora Colony',
      description: 'Beautiful rainbow acropora with amazing colors. Fully established and healthy.',
      startingBid: 25,
      currentBid: 45,
      bidCount: 8,
      timeLeft: 180, // 3 minutes
      endTime: new Date(Date.now() + 180000).toISOString(),
      image: 'https://images.unsplash.com/photo-1522802451138-8afd417be4bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGNvcmFsJTIwcmVlZiUyMGFxdWFyaXVtfGVufDF8fHx8MTc1ODA0ODMwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      isActive: true,
      reservePrice: 40,
      buyItNowPrice: 85,
      autoExtend: true,
      incrementType: 'fixed',
      minimumIncrement: 5,
      highestBidder: 'CoralFan123',
      sellerId: userToken || 'demo-seller',
      sellerName: 'Demo Seller'
    });

    setUpcomingItems([
      {
        id: 'upcoming_1',
        title: 'Orange Torch Coral',
        description: 'Vibrant orange torch coral',
        startingBid: 30,
        currentBid: 30,
        bidCount: 0,
        image: 'https://images.unsplash.com/photo-1638286269600-8f6f5d44cd84?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmFuZ2UlMjB0b3JjaCUyMGNvcmFsfGVufDF8fHx8MTc1ODA0ODMwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: 'upcoming_2',
        title: 'Blue Chalice Coral',
        description: 'Stunning blue chalice coral',
        startingBid: 20,
        currentBid: 20,
        bidCount: 0,
        image: 'https://images.unsplash.com/photo-1674801664581-b431ab58fe83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibHVlJTIwY2hhbGljZSUyMGNvcmFsfGVufDF8fHx8MTc1ODA0ODMxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]);
  };

  const initializeAgora = async () => {
    try {
      console.log('🎬 Creating Agora client with development-friendly settings...');
      console.log('🔧 Force real camera mode:', forceRealCamera);
      
      // Detect if we're in production deployment (not iframe preview)
      const isProductionDeployment = window.location.hostname !== 'localhost' && 
                                     window.location.hostname !== '127.0.0.1' && 
                                     window === window.parent; // Not in iframe

      // In production, always use real camera
      const shouldUseRealCamera = isProductionDeployment || forceRealCamera;
      
      // Request permissions first if in real camera mode and is host
      if (shouldUseRealCamera && isHost) {
        console.log('🔐 Requesting media permissions before Agora initialization...');
        
        try {
          const permissionsGranted = await Promise.race([
            requestMediaPermissions(),
            // Increase timeout to 30 seconds for permission request since we're being more aggressive
            new Promise<boolean>((resolve) => {
              setTimeout(() => {
                console.warn('⏰ Permission request timed out after 30 seconds');
                resolve(false);
              }, 30000);
            })
          ]);
          
          if (!permissionsGranted) {
            console.warn('⚠️ Permissions not granted or timed out');
            
            // In forceRealCamera mode, throw an error instead of falling back
            if (forceRealCamera) {
              throw new Error('Real camera mode requested but permissions were denied. Please allow camera and microphone access to stream with real camera.');
            } else {
              console.log('🎭 Falling back to demo mode due to permission denial');
              setIsEmbeddedMode(true);
              setSimulatedVideo(true);
              setLoading(false);
              return;
            }
          }
          
          // Double-check permissions by testing actual media access
          console.log('🔍 Verifying camera/microphone access after permission grant...');
          try {
            const testStream = await navigator.mediaDevices.getUserMedia({ 
              video: true, 
              audio: true 
            });
            
            console.log('✅ Media access verification successful');
            testStream.getTracks().forEach(track => track.stop());
            
            // Add a small delay to ensure browser fully processes the permission grant
            await new Promise(resolve => setTimeout(resolve, 1000));
            
          } catch (verifyError) {
            console.error('❌ Media access verification failed:', verifyError);
            console.log('🎭 Falling back to demo mode due to verification failure');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
            setLoading(false);
            return;
          }
          
        } catch (permissionError) {
          console.error('❌ Permission request failed:', permissionError);
          
          if (forceRealCamera) {
            // In real camera mode, show the error to user
            setError(permissionError.message || 'Failed to get camera permissions');
            setLoading(false);
            return;
          } else {
            console.log('🎭 Falling back to demo mode due to permission error');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
            setLoading(false);
            return;
          }
        }
      } else {
        // Not using real camera or not a host - set up demo mode immediately
        console.log('🎭 Setting up demo mode (not real camera or not host)');
        if (!isHost) {
          // For viewers, don't need to simulate video, just show waiting state
          setLoading(false);
        } else {
          // For hosts in demo mode, use simulated video
          setIsEmbeddedMode(true);
          setSimulatedVideo(true);
          setLoading(false);
          return;
        }
      }
      
      // Create Agora client with centralized config
      const agoraClient = createAgoraClient();

      setClient(agoraClient);

      // Set up event listeners
      agoraClient.on('user-published', handleUserPublished);
      agoraClient.on('user-unpublished', handleUserUnpublished);
      agoraClient.on('user-joined', handleUserJoined);
      agoraClient.on('user-left', handleUserLeft);

      // Get Agora token from server using safe API
      let responseData;
      
      try {
        const { api } = await import('../utils/api');
        responseData = await api.getAgoraToken({
          channelName, 
          role: isHost ? 'publisher' : 'subscriber',
          uid: userToken 
        });
        
        console.log('🎫 Received Agora token from server:', {
          hasToken: !!responseData.token,
          tokenType: responseData.tokenType,
          appId: responseData.appId,
          uid: responseData.uid,
          note: responseData.note
        });
        
        // If the server returned custom credentials, update client-side config
        if (responseData.tokenType === 'custom_credentials') {
          console.log('🔄 Server returned custom credentials - updating client config');
          // Sync credentials with frontend (this allows the config getter to work)
          if (responseData.appId) {
            globalThis.agoraAppId = responseData.appId;
            console.log('🔑 Updated client-side App ID from server credentials');
          }
        }
        
      } catch (fetchError) {
        console.warn('Failed to get Agora token from server, using fallback:', fetchError);
        
        // Fallback: Use centralized App ID with null token (for development/testing)
        responseData = {
          token: null, // Null token works for testing without certificate
          uid: userToken ? parseInt(userToken, 10) || Math.floor(Math.random() * 1000000) : Math.floor(Math.random() * 1000000), // Convert to number
          appId: AGORA_CONFIG.APP_ID,
          channelName,
          tokenType: 'fallback_config',
          note: 'Using client-side configuration (fallback mode)'
        };
        
        console.log('🔄 Using fallback Agora configuration:', {
          appId: responseData.appId,
          tokenType: responseData.tokenType,
          note: responseData.note
        });
      }

      const { token, uid, appId } = responseData;

      console.log('🚀 Joining Agora channel:', { appId, channelName, uid, hasToken: !!token });
      
      try {
        // Join channel with enhanced error handling
        await agoraClient.join(
          appId,
          channelName,
          token,
          uid
        );
        
        console.log('✅ Successfully joined Agora channel');
      } catch (joinError) {
        console.error('❌ Failed to join Agora channel:', joinError);
        
        // Handle specific Agora errors - always fall back to demo mode gracefully
        console.log('🎭 Agora join failed, switching to demo mode');
        setIsEmbeddedMode(true);
        setSimulatedVideo(true);
        setLoading(false);
        return;
      }

      // Add a small delay to ensure everything is properly initialized
      await new Promise(resolve => setTimeout(resolve, 500));

      // Only create tracks if we're a host AND we have verified permissions AND we're not in simulated mode
      if (isHost && shouldUseRealCamera && !simulatedVideo && !isEmbeddedMode) {
        // Create and publish local tracks for host with enhanced error handling
        console.log('🎬 Creating local audio and video tracks...');
        console.log('🔧 Force real camera mode:', forceRealCamera);
        
        try {
          let audioTrack = null;
          let videoTrack = null;
          
          // Try to create audio track with specific error handling
          try {
            console.log('🎤 Attempting to create microphone audio track...');
            audioTrack = await window.AgoraRTC.createMicrophoneAudioTrack({
              // Add audio constraints to avoid issues
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true
            });
            console.log('✅ Audio track created successfully');
          } catch (audioError) {
            console.warn('🎤 Microphone track creation failed:', audioError);
            
            // Don't try recovery - if we get here it means permissions failed
            console.log('🎭 Switching to demo mode due to audio track failure');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
            setLoading(false);
            return;
          }
          
          // Try to create video track with specific error handling
          try {
            console.log('📹 Attempting to create camera video track...');
            videoTrack = await window.AgoraRTC.createCameraVideoTrack({
              // Use more compatible video settings
              optimizationMode: "motion",
              encoderConfig: {
                width: 640,
                height: 480,
                frameRate: 15,
                bitrateMin: 400,
                bitrateMax: 1000,
              }
            });
            console.log('✅ Video track created successfully');
          } catch (videoError) {
            console.warn('📹 Camera track creation failed:', videoError);
            
            // Don't try recovery - if we get here it means permissions failed
            console.log('🎭 Switching to demo mode due to video track failure');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
            setLoading(false);
            return;
          }

          // Only set tracks that were successfully created
          if (audioTrack) {
            setLocalAudioTrack(audioTrack);
          }
          if (videoTrack) {
            setLocalVideoTrack(videoTrack);
          }

          // If we have no tracks, switch to demo mode
          if (!videoTrack && !audioTrack) {
            console.log('🎭 No media tracks available, switching to demo mode');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
            setLoading(false);
            return;
          }

          // Play local video if we have it
          if (videoTrack) {
            const playLocalVideo = async () => {
              let retries = 0;
              const maxRetries = 3;
              
              const attemptPlay = async () => {
                if (localVideoRef.current && videoTrack) {
                  try {
                    await videoTrack.play(localVideoRef.current);
                    console.log('✅ Local video is now playing');
                    return true;
                  } catch (playError) {
                    console.warn(`Failed to play local video (attempt ${retries + 1}):`, playError);
                    return false;
                  }
                }
                return false;
              };

              while (retries < maxRetries) {
                if (await attemptPlay()) {
                  break;
                }
                retries++;
                await new Promise(resolve => setTimeout(resolve, 200 * retries));
              }
              
              if (retries === maxRetries) {
                console.warn('Failed to play local video after all retries, continuing anyway');
              }
            };

            // Use setTimeout to ensure the ref is ready
            setTimeout(() => playLocalVideo(), 100);
          }

          // Publish only the tracks we successfully created
          const tracksToPublish = [audioTrack, videoTrack].filter(Boolean);
          if (tracksToPublish.length > 0) {
            console.log('📡 Publishing available tracks...', tracksToPublish.length);
            await agoraClient.publish(tracksToPublish);
            console.log('✅ Tracks published successfully');
          } else {
            console.log('⚠️ No tracks available to publish, continuing in demo mode');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
          }
          
        } catch (trackError) {
          console.error('Failed to create or publish tracks:', trackError);
          
          if (forceRealCamera) {
            // In real camera mode, show the error
            setError(trackError.message || 'Failed to initialize camera/microphone');
            setLoading(false);
            return;
          } else {
            console.log('🎭 Continuing in demo mode due to track error');
            setIsEmbeddedMode(true);
            setSimulatedVideo(true);
          }
        }
      } else {
        console.log('🎭 Skipping track creation - either not host, not real camera mode, or already in simulated mode');
      }

      setLoading(false);
      console.log('✅ Agora initialization completed successfully');
    } catch (err: any) {
      console.error('Agora initialization error:', err);
      
      if (forceRealCamera) {
        // In real camera mode, show the error
        setError(err.message || 'Failed to initialize livestream');
        setLoading(false);
      } else {
        // Always fall back to demo mode gracefully instead of showing error
        console.log('🎭 Initialization failed, falling back to demo mode');
        setIsEmbeddedMode(true);
        setSimulatedVideo(true);
        setLoading(false);
      }
    }
  };

  const handleUserPublished = async (user: any, mediaType: string) => {
    if (!client) return;

    try {
      await client.subscribe(user, mediaType);
      console.log(`📺 User ${user.uid} published ${mediaType}`);
      
      if (mediaType === 'video') {
        // Play video track in the remote video container
        const remoteVideoContainer = document.getElementById(`remote-video-${user.uid}`);
        if (remoteVideoContainer && user.videoTrack) {
          user.videoTrack.play(remoteVideoContainer);
        }
        
        setRemoteUsers(prev => {
          const existing = prev.find(u => u.uid === user.uid);
          if (existing) {
            return prev.map(u => u.uid === user.uid ? { ...u, hasVideo: true, videoTrack: user.videoTrack } : u);
          }
          return [...prev, { ...user, hasVideo: true, videoTrack: user.videoTrack }];
        });
      }

      if (mediaType === 'audio') {
        user.audioTrack?.play();
        setRemoteUsers(prev => 
          prev.map(u => u.uid === user.uid ? { ...u, hasAudio: true, audioTrack: user.audioTrack } : u)
        );
      }
    } catch (error) {
      console.error(`Failed to subscribe to ${mediaType} from user ${user.uid}:`, error);
    }
  };

  const handleUserUnpublished = (user: any, mediaType: string) => {
    if (mediaType === 'video') {
      setRemoteUsers(prev => 
        prev.map(u => u.uid === user.uid ? { ...u, hasVideo: false } : u)
      );
    }
  };

  const handleUserJoined = (user: any) => {
    setViewerCount(prev => prev + 1);
  };

  const handleUserLeft = (user: any) => {
    setRemoteUsers(prev => prev.filter(u => u.uid !== user.uid));
    setViewerCount(prev => Math.max(0, prev - 1));
  };

  const toggleMic = async () => {
    if (simulatedVideo) {
      // In simulated mode, just toggle the visual state
      setMicEnabled(!micEnabled);
      console.log(`🎤 Microphone ${!micEnabled ? 'enabled' : 'disabled'} (simulated)`);
    } else if (localAudioTrack) {
      try {
        await localAudioTrack.setEnabled(!micEnabled);
        setMicEnabled(!micEnabled);
        console.log(`🎤 Microphone ${!micEnabled ? 'enabled' : 'disabled'}`);
      } catch (error) {
        console.error('Failed to toggle microphone:', error);
      }
    }
  };

  const toggleCamera = async () => {
    if (simulatedVideo) {
      // In simulated mode, just toggle the visual state
      setCameraEnabled(!cameraEnabled);
      console.log(`📹 Camera ${!cameraEnabled ? 'enabled' : 'disabled'} (simulated)`);
    } else if (localVideoTrack) {
      try {
        await localVideoTrack.setEnabled(!cameraEnabled);
        setCameraEnabled(!cameraEnabled);
        console.log(`📹 Camera ${!cameraEnabled ? 'enabled' : 'disabled'}`);
      } catch (error) {
        console.error('Failed to toggle camera:', error);
      }
    }
  };

  const cleanup = async () => {
    if (localAudioTrack) {
      localAudioTrack.close();
    }
    if (localVideoTrack) {
      localVideoTrack.close();
    }
    if (client) {
      await client.leave();
    }
  };

  const handleLeave = async () => {
    await cleanup();
    onLeave();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          <p className="text-white">Connecting to livestream...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-400 text-6xl mb-4">⚠️</div>
          <h2 className="text-2xl font-bold text-white mb-2">Connection Error</h2>
          <p className="text-gray-400 mb-4">{error}</p>
          <button
            onClick={onLeave}
            className="bg-cyan-500 text-white px-6 py-2 rounded-lg hover:bg-cyan-400 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 relative">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/50 to-transparent p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full animate-pulse ${
                isEmbeddedMode ? 'bg-yellow-500' : 'bg-red-500'
              }`}></div>
              <span className="text-white font-medium">
                {isEmbeddedMode ? 'DEMO' : 'LIVE'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-white">
              <Users size={20} />
              <span>{viewerCount}</span>
            </div>
            
            {isEmbeddedMode && (
              <div className="bg-yellow-500/20 text-yellow-300 px-3 py-1 rounded-full text-sm">
                📱 Preview Mode
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            {isEmbeddedMode && (
              <button
                onClick={() => window.location.reload()}
                className="bg-cyan-500 text-white px-3 py-1 rounded-lg hover:bg-cyan-400 transition-colors text-sm"
                title="Reload with real camera permissions"
              >
                📹 Try Real Camera
              </button>
            )}
          </div>
          
          <button
            onClick={handleLeave}
            className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-400 transition-colors"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Main Video Area */}
      <div className="h-screen flex">
        {/* Primary Video */}
        <div className="flex-1 relative">
          {isHost ? (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center relative">
              {/* Real video track */}
              {localVideoTrack && !simulatedVideo && (
                <div 
                  ref={localVideoRef}
                  className="w-full h-full object-cover"
                  style={{ display: 'block' }}
                />
              )}
              
              {/* Simulated video for embedded mode */}
              {simulatedVideo && (
                <div className="w-full h-full relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-900 via-blue-900 to-teal-900">
                    {/* Animated coral reef background */}
                    <div className="absolute inset-0 opacity-30">
                      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-orange-400 rounded-full animate-pulse"></div>
                      <div className="absolute bottom-1/4 right-1/4 w-24 h-24 bg-pink-400 rounded-full animate-bounce"></div>
                      <div className="absolute top-1/2 left-1/2 w-16 h-16 bg-yellow-400 rounded-full animate-ping"></div>
                    </div>
                    
                    {/* Demo content overlay */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="text-6xl mb-4">🪸</div>
                        <h3 className="text-2xl font-bold mb-2">Live from Coral Crave!</h3>
                        <p className="text-lg opacity-80">Streaming Premium Coral Collection</p>
                        <div className="mt-4 px-3 py-1 bg-red-500 rounded-full text-sm font-medium inline-block animate-pulse">
                          🔴 LIVE
                        </div>
                      </div>
                    </div>
                    
                    {/* Embedded mode notice */}
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="bg-black/60 rounded-lg p-3 text-center">
                        <p className="text-sm text-gray-300 mb-2">
                          📱 Demo Mode - Camera access restricted in embedded environment
                        </p>
                        <p className="text-xs text-gray-400">
                          Want to see real camera? Add <code className="bg-gray-700 px-1 rounded">?realCamera=true</code> to the URL
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Camera disabled overlay */}
              {!cameraEnabled && !simulatedVideo && (
                <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">📹</span>
                    </div>
                    <p className="text-gray-400">Camera is off</p>
                  </div>
                </div>
              )}
              
              {/* Loading state */}
              {!localVideoTrack && !simulatedVideo && !error && (
                <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
                    <p className="text-gray-400">Starting camera...</p>
                    <p className="text-sm text-gray-500 mt-2">Please allow camera access when prompted</p>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              {remoteUsers.length > 0 ? (
                <div 
                  id={`remote-video-${remoteUsers[0]?.uid}`}
                  className="w-full h-full"
                />
              ) : (
                <div className="text-center">
                  <div className="text-6xl mb-4">📹</div>
                  <p className="text-gray-400">Waiting for stream to start...</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Chat Sidebar */}
        <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-white font-medium flex items-center gap-2">
              <MessageCircle size={20} />
              Live Chat
            </h3>
          </div>
          
          <div ref={chatContainerRef} className="flex-1 p-4 overflow-y-auto">
            <div className="space-y-3">
              {chatMessages.map((msg) => (
                <div key={msg.id} className="text-sm">
                  <span className="font-medium" style={{ color: msg.user.color }}>
                    {msg.user.name}:
                  </span>
                  <span className="text-gray-300 ml-2">{msg.message}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="p-4 border-t border-gray-700">
            <div className="flex gap-2">
              <input
                type="text"
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message..."
                className="flex-1 bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none text-sm"
              />
              <button 
                onClick={handleSendMessage}
                className="bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-400 transition-colors text-sm"
              >
                Send
              </button>
            </div>
          </div>
        </div>
        
        {/* Bidding Panel Sidebar */}
        <div className="w-80 bg-gray-800 border-l border-gray-700">
          <DemoBiddingPanel 
            currentItem={currentAuctionItem}
            upcomingItems={upcomingItems}
            user={getDummyUser()}
            onBid={handleBid}
            onAuthRequired={handleAuthRequired}
            demoMode={true}
            hostUserId={isHost ? userToken : undefined} // Pass host ID if current user is host
          />
        </div>
      </div>

      {/* Bottom Action Panels */}
      <div className="absolute bottom-4 left-4 right-4 pointer-events-none">
        <div className="flex justify-center">
          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Stream Controls for Host */}
            {isHost && (
              <>
                <button
                  onClick={() => setShowAuctionQueue(!showAuctionQueue)}
                  className={`p-3 rounded-full transition-colors ${
                    showAuctionQueue ? 'bg-cyan-500 hover:bg-cyan-600' : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                  title="Manage Auction Queue"
                >
                  <Gavel size={20} />
                </button>
                
                <button
                  onClick={toggleMic}
                  className={`p-3 rounded-full transition-colors flex items-center gap-2 ${
                    micEnabled 
                      ? 'bg-green-500 hover:bg-green-400 text-white' 
                      : 'bg-red-500 hover:bg-red-400 text-white'
                  }`}
                >
                  {micEnabled ? <Mic size={18} /> : <MicOff size={18} />}
                </button>
                
                <button
                  onClick={toggleCamera}
                  className={`p-3 rounded-full transition-colors flex items-center gap-2 ${
                    cameraEnabled 
                      ? 'bg-green-500 hover:bg-green-400 text-white' 
                      : 'bg-red-500 hover:bg-red-400 text-white'
                  }`}
                >
                  {cameraEnabled ? <Video size={18} /> : <VideoOff size={18} />}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Live Auction Queue - Bottom Panel for Hosts */}
      {isHost && (
        <div className="absolute bottom-0 left-0 right-0 bg-gray-900/95 backdrop-blur-sm border-t border-gray-700 pointer-events-auto">
          <div className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-medium flex items-center gap-2">
                <Gavel size={20} className="text-cyan-400" />
                Live Auction Queue
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400">
                  {upcomingItems.length} items ready
                </span>
                <button
                  onClick={() => setShowAddItemModal(true)}
                  className="px-3 py-1 rounded-lg text-sm font-medium transition-colors bg-green-600 text-white hover:bg-green-700 flex items-center gap-1"
                  title="Add New Item to Queue"
                >
                  <Plus size={14} />
                  Add Item
                </button>
                <button
                  onClick={() => setShowAuctionQueue(!showAuctionQueue)}
                  className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                    showAuctionQueue 
                      ? 'bg-cyan-500 text-white hover:bg-cyan-600' 
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  {showAuctionQueue ? 'Hide Queue' : 'Show Queue'}
                </button>
              </div>
            </div>
            
            {/* Quick Queue View - Always visible */}
            <div className="flex gap-3 overflow-x-auto pb-2">
              {upcomingItems.slice(0, 4).map((item, index) => (
                <div 
                  key={item.id}
                  className="flex-shrink-0 bg-gray-800 rounded-lg p-3 min-w-[200px] border border-gray-600 hover:border-cyan-400 transition-colors cursor-pointer"
                  onClick={() => handleStartAuction(item)}
                >
                  <div className="flex items-center gap-3">
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-white font-medium text-sm truncate">{item.title}</h4>
                      <p className="text-cyan-400 text-sm">${item.startingBid}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-xs text-gray-400">#{index + 1} in queue</span>
                        <button className="text-xs bg-cyan-500 text-white px-2 py-1 rounded hover:bg-cyan-600 transition-colors">
                          Start Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {upcomingItems.length === 0 && (
                <div className="flex-shrink-0 bg-gray-800/50 rounded-lg p-4 min-w-[300px] border border-gray-600 border-dashed">
                  <div className="text-center text-gray-400">
                    <Gavel size={24} className="mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No items in queue</p>
                    <p className="text-xs mt-1">Add items to start auctions</p>
                  </div>
                </div>
              )}
            </div>
            
            {/* Stream Controls Bar - Above auction queue */}
            <div className="flex justify-center pt-2 border-t border-gray-700 mt-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleMic}
                  className={`p-2 rounded-full transition-colors ${
                    micEnabled 
                      ? 'bg-green-500 hover:bg-green-400 text-white' 
                      : 'bg-red-500 hover:bg-red-400 text-white'
                  }`}
                  title={micEnabled ? 'Mute Microphone' : 'Unmute Microphone'}
                >
                  {micEnabled ? <Mic size={16} /> : <MicOff size={16} />}
                </button>
                
                <button
                  onClick={toggleCamera}
                  className={`p-2 rounded-full transition-colors ${
                    cameraEnabled 
                      ? 'bg-green-500 hover:bg-green-400 text-white' 
                      : 'bg-red-500 hover:bg-red-400 text-white'
                  }`}
                  title={cameraEnabled ? 'Turn Off Camera' : 'Turn On Camera'}
                >
                  {cameraEnabled ? <Video size={16} /> : <VideoOff size={16} />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Item Modal */}
      {showAddItemModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-xl max-w-md w-full border border-gray-700">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Plus size={20} className="text-green-400" />
                  Add New Item to Queue
                </h2>
                <button
                  onClick={() => setShowAddItemModal(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Item Title *
                  </label>
                  <input
                    type="text"
                    value={newItemForm.title}
                    onChange={(e) => setNewItemForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="e.g., Rainbow Acropora Colony"
                    className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                    maxLength={100}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    value={newItemForm.description}
                    onChange={(e) => setNewItemForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of the item..."
                    className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none resize-none"
                    rows={3}
                    maxLength={500}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Starting Bid *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
                    <input
                      type="number"
                      value={newItemForm.startingBid}
                      onChange={(e) => setNewItemForm(prev => ({ ...prev, startingBid: e.target.value }))}
                      placeholder="25.00"
                      min="0.01"
                      step="0.01"
                      className="w-full bg-gray-700 text-white pl-8 pr-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Auction Timer (seconds)
                  </label>
                  <select
                    value={newItemForm.timer}
                    onChange={(e) => setNewItemForm(prev => ({ ...prev, timer: e.target.value }))}
                    className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  >
                    <option value="180">3 minutes</option>
                    <option value="300">5 minutes</option>
                    <option value="420">7 minutes</option>
                    <option value="600">10 minutes</option>
                  </select>
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowAddItemModal(false)}
                  className="flex-1 bg-gray-700 text-gray-300 py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddItem}
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
                >
                  Add to Queue
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Expanded Auction Queue Modal - Only shows when toggled */}
      {showAuctionQueue && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-xl max-w-4xl w-full max-h-[80vh] overflow-hidden border border-gray-700">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">Full Auction Queue</h2>
                <button
                  onClick={() => setShowAuctionQueue(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
              </div>
              
              <AuctionQueue
                user={getDummyUser()}
                onStartAuction={handleStartAuction}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}