import { Hono } from 'npm:hono'

interface QueuedItem {
  id: string;
  sellerId: string;
  sellerName: string;
  title: string;
  description: string;
  category: string;
  startingBid: number;
  reservePrice?: number;
  buyItNowPrice?: number;
  duration: number; // in minutes
  images: string[];
  status: 'queued' | 'active' | 'completed' | 'cancelled';
  queuedAt: string;
  startedAt?: string;
  endedAt?: string;
  currentBid: number;
  bidCount: number;
  highestBidder?: string;
  autoExtend: boolean;
  incrementType: 'fixed' | 'percentage';
  minimumIncrement: number;
}

interface Bid {
  id: string;
  itemId: string;
  userId: string;
  userName: string;
  amount: number;
  maxAmount?: number; // For proxy bidding
  isProxyBid: boolean;
  timestamp: string;
  status: 'active' | 'outbid' | 'winning';
}

interface NotificationSubscription {
  userId: string;
  itemId?: string;
  sellerId?: string;
  type: 'outbid' | 'auction_ending' | 'new_item' | 'price_drop' | 'auction_won';
  isActive: boolean;
}

// Auction Queue Management
export function createAuctionQueueRoutes(app: Hono, supabase: any) {
  
  // Test endpoint for auction queue system
  app.get('/make-server-9f7745d8/auction-queue/test', async (c) => {
    try {
      console.log('🧪 Auction queue test endpoint accessed');
      
      const kvModule = await import('./kv_store.tsx');
      
      // Test basic KV operations
      const testKey = 'test_queue_operation';
      const testData = { test: true, timestamp: new Date().toISOString() };
      
      await kvModule.set(testKey, testData);
      const retrievedData = await kvModule.get(testKey);
      await kvModule.del(testKey);
      
      console.log('✅ Auction queue test completed successfully');
      
      return c.json({
        success: true,
        message: 'Auction queue system is operational',
        kvStore: {
          canWrite: !!retrievedData,
          canRead: !!retrievedData,
          canDelete: true,
          testData: retrievedData
        },
        endpoints: {
          getQueue: '/queue/:sellerId',
          addItem: '/queue/add',
          startAuction: '/queue/start/:itemId',
          removeItem: '/queue/:itemId',
          placeBid: '/bid/place',
          getActiveAuctions: '/auctions/active'
        },
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('❌ Auction queue test failed:', error);
      return c.json({
        success: false,
        error: 'Auction queue test failed',
        details: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      }, 500);
    }
  });

  // Get seller's auction queue
  app.get('/make-server-9f7745d8/queue/:sellerId', async (c) => {
    try {
      const sellerId = c.req.param('sellerId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user || user.id !== sellerId) {
        return c.json({ error: 'Unauthorized access to queue' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const queueItems = await kvModule.get(`seller_queue:${sellerId}`) || [];
      
      // Get detailed item data
      const detailedItems = [];
      for (const itemId of queueItems) {
        const item = await kvModule.get(`queue_item:${itemId}`);
        if (item) {
          detailedItems.push(item);
        }
      }

      // Sort by queue order
      detailedItems.sort((a, b) => new Date(a.queuedAt).getTime() - new Date(b.queuedAt).getTime());

      return c.json({
        success: true,
        items: detailedItems
      });

    } catch (error) {
      console.error('Queue fetch error:', error);
      return c.json({ 
        error: 'Failed to fetch auction queue', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Add item to queue
  app.post('/make-server-9f7745d8/queue/add', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const itemData = await c.req.json();
      const { 
        title, 
        description, 
        category, 
        startingBid, 
        reservePrice, 
        buyItNowPrice,
        duration = 30, 
        images = [],
        autoExtend = true,
        incrementType = 'fixed',
        minimumIncrement = 5
      } = itemData;

      if (!title || !description || !startingBid) {
        return c.json({ error: 'Title, description, and starting bid are required' }, 400);
      }

      const itemId = `item_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const queuedItem: QueuedItem = {
        id: itemId,
        sellerId: user.id,
        sellerName: user.user_metadata?.name || user.email || 'Unknown Seller',
        title,
        description,
        category: category || 'General',
        startingBid: parseFloat(startingBid),
        reservePrice: reservePrice ? parseFloat(reservePrice) : undefined,
        buyItNowPrice: buyItNowPrice ? parseFloat(buyItNowPrice) : undefined,
        duration: parseInt(duration),
        images,
        status: 'queued',
        queuedAt: new Date().toISOString(),
        currentBid: parseFloat(startingBid),
        bidCount: 0,
        autoExtend,
        incrementType,
        minimumIncrement: parseFloat(minimumIncrement)
      };

      const kvModule = await import('./kv_store.tsx');
      
      // Save item
      await kvModule.set(`queue_item:${itemId}`, queuedItem);
      
      // Add to seller's queue
      const sellerQueue = await kvModule.get(`seller_queue:${user.id}`) || [];
      sellerQueue.push(itemId);
      await kvModule.set(`seller_queue:${user.id}`, sellerQueue);

      console.log('✅ Item added to queue:', itemId);

      return c.json({
        success: true,
        item: queuedItem
      });

    } catch (error) {
      console.error('Add to queue error:', error);
      return c.json({ 
        error: 'Failed to add item to queue', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Start auction from queue
  app.post('/make-server-9f7745d8/queue/start/:itemId', async (c) => {
    try {
      const itemId = c.req.param('itemId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const item = await kvModule.get(`queue_item:${itemId}`);
      
      if (!item) {
        return c.json({ error: 'Item not found in queue' }, 404);
      }

      if (item.sellerId !== user.id) {
        return c.json({ error: 'Unauthorized to start this auction' }, 401);
      }

      if (item.status !== 'queued') {
        return c.json({ error: 'Item is not queued for auction' }, 400);
      }

      // Check if seller has an active auction
      const activeAuctions = await kvModule.get(`active_auctions:${user.id}`) || [];
      if (activeAuctions.length > 0) {
        return c.json({ error: 'You already have an active auction. Complete it before starting another.' }, 400);
      }

      // Start the auction
      const startTime = new Date();
      const endTime = new Date(startTime.getTime() + item.duration * 60000);
      
      const updatedItem = {
        ...item,
        status: 'active',
        startedAt: startTime.toISOString(),
        endedAt: endTime.toISOString()
      };

      await kvModule.set(`queue_item:${itemId}`, updatedItem);
      await kvModule.set(`active_auction:${itemId}`, updatedItem);
      
      // Add to seller's active auctions
      activeAuctions.push(itemId);
      await kvModule.set(`active_auctions:${user.id}`, activeAuctions);

      // Add to global active auctions list
      const globalActive = await kvModule.get('global_active_auctions') || [];
      globalActive.push(itemId);
      await kvModule.set('global_active_auctions', globalActive);

      // Notify followers
      await notifyFollowers(user.id, 'new_item', updatedItem, kvModule);

      console.log('✅ Auction started:', itemId);

      return c.json({
        success: true,
        auction: updatedItem,
        message: 'Auction started successfully!'
      });

    } catch (error) {
      console.error('Start auction error:', error);
      return c.json({ 
        error: 'Failed to start auction', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Get active auctions
  app.get('/make-server-9f7745d8/auctions/active', async (c) => {
    try {
      const kvModule = await import('./kv_store.tsx');
      const activeAuctionIds = await kvModule.get('global_active_auctions') || [];
      
      const activeAuctions = [];
      for (const itemId of activeAuctionIds) {
        const auction = await kvModule.get(`active_auction:${itemId}`);
        if (auction && auction.status === 'active') {
          // Check if auction has ended
          const endTime = new Date(auction.endedAt);
          const now = new Date();
          
          if (now > endTime) {
            // End the auction
            await endAuction(itemId, auction, kvModule);
          } else {
            activeAuctions.push(auction);
          }
        }
      }

      return c.json({
        success: true,
        auctions: activeAuctions
      });

    } catch (error) {
      console.error('Active auctions fetch error:', error);
      return c.json({ 
        error: 'Failed to fetch active auctions', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Remove item from queue
  app.delete('/make-server-9f7745d8/queue/:itemId', async (c) => {
    try {
      const itemId = c.req.param('itemId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const item = await kvModule.get(`queue_item:${itemId}`);
      
      if (!item) {
        return c.json({ error: 'Item not found' }, 404);
      }

      if (item.sellerId !== user.id) {
        return c.json({ error: 'Unauthorized to remove this item' }, 401);
      }

      if (item.status === 'active') {
        return c.json({ error: 'Cannot remove active auction item' }, 400);
      }

      // Remove from queue
      const sellerQueue = await kvModule.get(`seller_queue:${user.id}`) || [];
      const updatedQueue = sellerQueue.filter((id: string) => id !== itemId);
      await kvModule.set(`seller_queue:${user.id}`, updatedQueue);

      // Delete item
      await kvModule.del(`queue_item:${itemId}`);

      return c.json({
        success: true,
        message: 'Item removed from queue'
      });

    } catch (error) {
      console.error('Remove queue item error:', error);
      return c.json({ 
        error: 'Failed to remove item from queue', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });
}

// Enhanced Bidding System
export function createEnhancedBiddingRoutes(app: Hono, supabase: any) {
  
  // Place bid with proxy bidding support
  app.post('/make-server-9f7745d8/bid/place', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const { itemId, amount, maxAmount, isProxyBid = false } = await c.req.json();

      if (!itemId || !amount) {
        return c.json({ error: 'Item ID and bid amount are required' }, 400);
      }

      const kvModule = await import('./kv_store.tsx');
      const auction = await kvModule.get(`active_auction:${itemId}`);
      
      if (!auction) {
        return c.json({ error: 'Auction not found or not active' }, 404);
      }

      // Check if auction is still active
      const endTime = new Date(auction.endedAt);
      const now = new Date();
      
      if (now > endTime) {
        return c.json({ error: 'Auction has ended' }, 400);
      }

      // Calculate minimum bid
      const minBid = calculateMinimumBid(auction);
      const bidAmount = parseFloat(amount);
      
      if (bidAmount < minBid) {
        return c.json({ error: `Minimum bid is $${minBid}` }, 400);
      }

      // Process the bid
      const bidResult = await processBid(itemId, user, bidAmount, maxAmount, isProxyBid, auction, kvModule);

      if (!bidResult.success) {
        return c.json({ error: bidResult.error }, 400);
      }

      // Check for auction extension
      const timeLeft = endTime.getTime() - now.getTime();
      if (auction.autoExtend && timeLeft < 30000) { // Less than 30 seconds
        const newEndTime = new Date(now.getTime() + 60000); // Extend by 1 minute
        auction.endedAt = newEndTime.toISOString();
        await kvModule.set(`active_auction:${itemId}`, auction);
        console.log('🕐 Auction extended due to last-second bid');
      }

      return c.json({
        success: true,
        bid: bidResult.bid,
        auction: bidResult.auction,
        message: bidResult.message
      });

    } catch (error) {
      console.error('Bid placement error:', error);
      return c.json({ 
        error: 'Failed to place bid', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Get bid history for an item
  app.get('/make-server-9f7745d8/bids/:itemId', async (c) => {
    try {
      const itemId = c.req.param('itemId');
      const kvModule = await import('./kv_store.tsx');
      
      const bidHistory = await kvModule.get(`bid_history:${itemId}`) || [];
      
      return c.json({
        success: true,
        bids: bidHistory
      });

    } catch (error) {
      console.error('Bid history fetch error:', error);
      return c.json({ 
        error: 'Failed to fetch bid history', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Set up auto-bidding (proxy bidding)
  app.post('/make-server-9f7745d8/bid/auto-setup', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const { itemId, maxAmount } = await c.req.json();

      if (!itemId || !maxAmount) {
        return c.json({ error: 'Item ID and maximum amount are required' }, 400);
      }

      const kvModule = await import('./kv_store.tsx');
      
      // Store auto-bid settings
      const autoBidKey = `auto_bid:${user.id}:${itemId}`;
      const autoBidData = {
        userId: user.id,
        itemId,
        maxAmount: parseFloat(maxAmount),
        isActive: true,
        createdAt: new Date().toISOString()
      };

      await kvModule.set(autoBidKey, autoBidData);

      return c.json({
        success: true,
        message: `Auto-bidding set up with maximum of $${maxAmount}`
      });

    } catch (error) {
      console.error('Auto-bid setup error:', error);
      return c.json({ 
        error: 'Failed to set up auto-bidding', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });
}

// Helper Functions
async function processBid(itemId: string, user: any, amount: number, maxAmount: number | undefined, isProxyBid: boolean, auction: QueuedItem, kvModule: any) {
  try {
    const bidId = `bid_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Check for existing proxy bids and handle competition
    const autoBids = await getActiveProxyBids(itemId, kvModule);
    
    const bid: Bid = {
      id: bidId,
      itemId,
      userId: user.id,
      userName: user.user_metadata?.name || user.email || 'Anonymous',
      amount,
      maxAmount,
      isProxyBid,
      timestamp: new Date().toISOString(),
      status: 'winning'
    };

    // Update auction with new bid
    auction.currentBid = amount;
    auction.bidCount += 1;
    auction.highestBidder = user.id;

    // Save bid
    const bidHistory = await kvModule.get(`bid_history:${itemId}`) || [];
    
    // Mark previous bids as outbid
    bidHistory.forEach((b: Bid) => {
      if (b.status === 'winning') {
        b.status = 'outbid';
      }
    });
    
    bidHistory.push(bid);
    await kvModule.set(`bid_history:${itemId}`, bidHistory);
    await kvModule.set(`active_auction:${itemId}`, auction);

    // Handle proxy bidding competition
    if (isProxyBid && maxAmount && autoBids.length > 0) {
      await handleProxyBidCompetition(itemId, bid, autoBids, auction, kvModule);
    }

    // Send notifications for outbid users
    await notifyOutbidUsers(itemId, user.id, amount, kvModule);

    return {
      success: true,
      bid,
      auction,
      message: isProxyBid ? 'Auto-bid placed successfully' : 'Bid placed successfully'
    };

  } catch (error) {
    console.error('Process bid error:', error);
    return {
      success: false,
      error: 'Failed to process bid'
    };
  }
}

async function getActiveProxyBids(itemId: string, kvModule: any): Promise<any[]> {
  try {
    // This would need to scan for auto-bid entries for this item
    // For now, return empty array - in production you'd query the KV store
    return [];
  } catch (error) {
    console.error('Get proxy bids error:', error);
    return [];
  }
}

async function handleProxyBidCompetition(itemId: string, newBid: Bid, existingProxyBids: any[], auction: QueuedItem, kvModule: any) {
  // Implementation for handling multiple proxy bids competing
  // This would automatically place counter-bids up to user limits
  console.log('🤖 Handling proxy bid competition...');
}

function calculateMinimumBid(auction: QueuedItem): number {
  if (auction.incrementType === 'percentage') {
    return auction.currentBid * (1 + auction.minimumIncrement / 100);
  } else {
    return auction.currentBid + auction.minimumIncrement;
  }
}

async function notifyOutbidUsers(itemId: string, newBidderId: string, newAmount: number, kvModule: any) {
  try {
    const bidHistory = await kvModule.get(`bid_history:${itemId}`) || [];
    const outbidUsers = bidHistory
      .filter((bid: Bid) => bid.userId !== newBidderId && bid.status === 'outbid')
      .map((bid: Bid) => bid.userId);

    // Store notifications for outbid users
    for (const userId of outbidUsers) {
      const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const notification = {
        id: notificationId,
        userId,
        type: 'outbid',
        itemId,
        message: `You've been outbid on an item. New bid: $${newAmount}`,
        read: false,
        createdAt: new Date().toISOString()
      };

      const userNotifications = await kvModule.get(`notifications:${userId}`) || [];
      userNotifications.unshift(notification);
      await kvModule.set(`notifications:${userId}`, userNotifications.slice(0, 100)); // Keep last 100
    }

    console.log('📢 Outbid notifications sent to', outbidUsers.length, 'users');
  } catch (error) {
    console.error('Notify outbid users error:', error);
  }
}

async function notifyFollowers(sellerId: string, type: string, item: QueuedItem, kvModule: any) {
  try {
    const followers = await kvModule.get(`followers:${sellerId}`) || [];
    
    for (const followerId of followers) {
      const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const notification = {
        id: notificationId,
        userId: followerId,
        type: 'new_item',
        itemId: item.id,
        message: `${item.sellerName} started a new auction: ${item.title}`,
        read: false,
        createdAt: new Date().toISOString()
      };

      const userNotifications = await kvModule.get(`notifications:${followerId}`) || [];
      userNotifications.unshift(notification);
      await kvModule.set(`notifications:${followerId}`, userNotifications.slice(0, 100));
    }

    console.log('📢 New item notifications sent to', followers.length, 'followers');
  } catch (error) {
    console.error('Notify followers error:', error);
  }
}

async function endAuction(itemId: string, auction: QueuedItem, kvModule: any) {
  try {
    auction.status = 'completed';
    auction.endedAt = new Date().toISOString();
    
    await kvModule.set(`queue_item:${itemId}`, auction);
    await kvModule.set(`completed_auction:${itemId}`, auction);
    await kvModule.del(`active_auction:${itemId}`);

    // Remove from active lists
    const globalActive = await kvModule.get('global_active_auctions') || [];
    const updatedGlobal = globalActive.filter((id: string) => id !== itemId);
    await kvModule.set('global_active_auctions', updatedGlobal);

    const sellerActive = await kvModule.get(`active_auctions:${auction.sellerId}`) || [];
    const updatedSeller = sellerActive.filter((id: string) => id !== itemId);
    await kvModule.set(`active_auctions:${auction.sellerId}`, updatedSeller);

    // Notify winner
    if (auction.highestBidder) {
      const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const notification = {
        id: notificationId,
        userId: auction.highestBidder,
        type: 'auction_won',
        itemId,
        message: `Congratulations! You won "${auction.title}" for $${auction.currentBid}`,
        read: false,
        createdAt: new Date().toISOString()
      };

      const userNotifications = await kvModule.get(`notifications:${auction.highestBidder}`) || [];
      userNotifications.unshift(notification);
      await kvModule.set(`notifications:${auction.highestBidder}`, userNotifications.slice(0, 100));
    }

    console.log('🏁 Auction ended:', itemId);
  } catch (error) {
    console.error('End auction error:', error);
  }
}