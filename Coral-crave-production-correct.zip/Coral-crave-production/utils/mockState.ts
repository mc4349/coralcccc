// Mock State Manager for QA Checklist Requirements
// This simulates realtime state without network calls as required by Figma QA checklist

export interface MockAuctionState {
  current_highest: number;
  min_increment: number;
  status: 'active' | 'ended' | 'pending';
  viewer_count: number;
  time_remaining: number;
  item_name: string;
  seller_name: string;
}

export interface MockChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  type: 'message' | 'bid' | 'system';
}

class MockStateManager {
  private auctionState: MockAuctionState;
  private chatMessages: MockChatMessage[];
  private timerId: NodeJS.Timeout | null = null;
  private listeners: Array<(state: MockAuctionState) => void> = [];
  private chatListeners: Array<(messages: MockChatMessage[]) => void> = [];

  constructor() {
    this.auctionState = {
      current_highest: 45,
      min_increment: 5,
      status: 'active',
      viewer_count: 23,
      time_remaining: 300, // 5 minutes in seconds
      item_name: 'Rainbow Acropora Colony',
      seller_name: 'ReefMaster42'
    };

    this.chatMessages = [
      {
        id: '1',
        username: 'CoralCollector',
        message: 'Beautiful piece!',
        timestamp: new Date(Date.now() - 300000),
        type: 'message'
      },
      {
        id: '2',
        username: 'ReefFan42',
        message: 'bid $45',
        timestamp: new Date(Date.now() - 250000),
        type: 'bid'
      }
    ];

    this.startTimer();
  }

  // Subscribe to auction state changes
  onStateChange(callback: (state: MockAuctionState) => void) {
    this.listeners.push(callback);
    // Immediately call with current state
    callback(this.auctionState);
    
    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  // Subscribe to chat messages
  onChatChange(callback: (messages: MockChatMessage[]) => void) {
    this.chatListeners.push(callback);
    // Immediately call with current messages
    callback([...this.chatMessages]);
    
    // Return unsubscribe function
    return () => {
      this.chatListeners = this.chatListeners.filter(l => l !== callback);
    };
  }

  // Simulate bid increment
  simulateBid() {
    if (this.auctionState.status !== 'active') return;

    const newBid = this.auctionState.current_highest + this.auctionState.min_increment;
    this.auctionState.current_highest = newBid;

    // Add chat message for bid
    const bidMessage: MockChatMessage = {
      id: Date.now().toString(),
      username: `Bidder${Math.floor(Math.random() * 100)}`,
      message: `bid $${newBid}`,
      timestamp: new Date(),
      type: 'bid'
    };

    this.chatMessages.push(bidMessage);

    // Notify listeners
    this.notifyStateListeners();
    this.notifyChatListeners();

    // Increase viewer count slightly
    this.auctionState.viewer_count += Math.floor(Math.random() * 3);
  }

  // Place a manual bid
  placeBid(amount: number, username: string = 'You'): { success: boolean; error?: string } {
    if (this.auctionState.status !== 'active') {
      return { success: false, error: 'This auction has ended' };
    }

    const minBid = this.auctionState.current_highest + this.auctionState.min_increment;
    if (amount < minBid) {
      return { success: false, error: `Min bid is $${minBid}` };
    }

    this.auctionState.current_highest = amount;
    
    // Add chat message for bid
    const bidMessage: MockChatMessage = {
      id: Date.now().toString(),
      username,
      message: `bid $${amount}`,
      timestamp: new Date(),
      type: 'bid'
    };

    this.chatMessages.push(bidMessage);

    // Notify listeners
    this.notifyStateListeners();
    this.notifyChatListeners();

    return { success: true };
  }

  // Add chat message
  addChatMessage(message: string, username: string = 'You') {
    const chatMessage: MockChatMessage = {
      id: Date.now().toString(),
      username,
      message,
      timestamp: new Date(),
      type: 'message'
    };

    this.chatMessages.push(chatMessage);
    this.notifyChatListeners();
  }

  // Get current state
  getCurrentState(): MockAuctionState {
    return { ...this.auctionState };
  }

  // Get current messages
  getCurrentMessages(): MockChatMessage[] {
    return [...this.chatMessages];
  }

  // Start the countdown timer
  private startTimer() {
    if (this.timerId) clearInterval(this.timerId);

    this.timerId = setInterval(() => {
      if (this.auctionState.status === 'active' && this.auctionState.time_remaining > 0) {
        this.auctionState.time_remaining -= 1;
        
        // Occasionally simulate automatic bids
        if (Math.random() < 0.1) { // 10% chance per second
          this.simulateBid();
        }

        // End auction when timer reaches 0
        if (this.auctionState.time_remaining <= 0) {
          this.auctionState.status = 'ended';
          this.auctionState.time_remaining = 0;
          
          // Add system message
          const endMessage: MockChatMessage = {
            id: Date.now().toString(),
            username: 'System',
            message: `Auction ended! Winner: $${this.auctionState.current_highest}`,
            timestamp: new Date(),
            type: 'system'
          };
          
          this.chatMessages.push(endMessage);
          this.notifyChatListeners();
        }

        this.notifyStateListeners();
      }
    }, 1000);
  }

  // Reset auction state (for testing)
  resetAuction() {
    this.auctionState = {
      current_highest: 45,
      min_increment: 5,
      status: 'active',
      viewer_count: 23,
      time_remaining: 300,
      item_name: 'Rainbow Acropora Colony',
      seller_name: 'ReefMaster42'
    };

    this.chatMessages = [
      {
        id: '1',
        username: 'CoralCollector',
        message: 'Beautiful piece!',
        timestamp: new Date(Date.now() - 300000),
        type: 'message'
      }
    ];

    this.notifyStateListeners();
    this.notifyChatListeners();
  }

  // Set auction to end in X seconds (for testing)
  setTimeRemaining(seconds: number) {
    this.auctionState.time_remaining = seconds;
    this.notifyStateListeners();
  }

  // Clean up
  destroy() {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
    this.listeners = [];
    this.chatListeners = [];
  }

  private notifyStateListeners() {
    this.listeners.forEach(listener => listener({ ...this.auctionState }));
  }

  private notifyChatListeners() {
    this.chatListeners.forEach(listener => listener([...this.chatMessages]));
  }
}

// Create singleton instance for global state
export const mockState = new MockStateManager();

// Helper functions for QA checklist requirements
export const calculateFees = (bidAmount: number) => {
  const commission = bidAmount * 0.08; // 8%
  const processing = bidAmount * 0.029 + 0.30; // 2.9% + $0.30
  const total = commission + processing;
  const payout = bidAmount - total;

  return {
    bidAmount,
    commission,
    processing,
    totalFees: total,
    sellerPayout: payout
  };
};

// Test cases from QA checklist
export const testFeeCalculations = () => {
  console.log('Fee Calculation Tests:');
  
  const test1 = calculateFees(100);
  console.log(`Test 1: Bid $100 → Fees: $${test1.commission.toFixed(2)} + $${test1.processing.toFixed(2)} → Net $${test1.sellerPayout.toFixed(2)}`);
  // Expected: Fees: $8.00 + $3.20 → Net $88.80
  
  const test2 = calculateFees(57);
  console.log(`Test 2: Bid $57 → Fees: $${test2.commission.toFixed(2)} + $${test2.processing.toFixed(2)} → Net $${test2.sellerPayout.toFixed(2)}`);
  // Expected: Fees: $4.56 + $1.95 → Net $50.49
  
  return { test1, test2 };
};

// Format time remaining for display
export const formatTimeRemaining = (seconds: number): string => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
};

export default mockState;