import React, { useState, useEffect } from 'react';
import { X, Video, Image, Loader2, AlertCircle, CheckCircle2, ExternalLink } from 'lucide-react';
import { supabase } from '../utils/supabase/client';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface GoLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartStream: (data: { title: string; description: string; channelName: string; thumbnail?: string }) => void;
  user?: any;
}

export function GoLiveModal({ isOpen, onClose, onStartStream, user }: GoLiveModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isStarting, setIsStarting] = useState(false);
  const [paypalConnected, setPaypalConnected] = useState(false);
  const [checkingPayPal, setCheckingPayPal] = useState(true);
  const [paypalError, setPaypalError] = useState<string | null>(null);

  // Check PayPal connection status when modal opens
  useEffect(() => {
    if (isOpen && user) {
      checkPayPalConnection();
    }
  }, [isOpen, user]);

  const checkPayPalConnection = async () => {
    try {
      setCheckingPayPal(true);
      setPaypalError(null);
      
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('Not authenticated');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/merchant-status`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.success) {
        setPaypalConnected(data.status === 'CONNECTED');
      } else {
        throw new Error(data.error || 'Failed to check PayPal status');
      }
    } catch (error) {
      console.error('Error checking PayPal status:', error);
      setPaypalError(error instanceof Error ? error.message : 'Failed to check PayPal status');
      setPaypalConnected(false);
    } finally {
      setCheckingPayPal(false);
    }
  };

  const handleConnectPayPal = async () => {
    try {
      setPaypalError(null);
      
      // Get fresh session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError) {
        console.error('Session error:', sessionError);
        throw new Error('Session error. Please sign out and sign in again.');
      }
      
      if (!session?.access_token) {
        console.error('No session found:', session);
        throw new Error('Not authenticated. Please sign out and sign in again.');
      }

      console.log('🔑 Using session token for PayPal connection (length:', session.access_token.length, ')');

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/onboarding-link`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: user?.id,
          email: user?.email,
          name: user?.name
        })
      });

      console.log('📡 PayPal onboarding response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ PayPal onboarding API error:', errorText);
        
        if (response.status === 401) {
          throw new Error('Authentication failed. Please sign out and sign in again.');
        }
        
        throw new Error(`PayPal connection failed (${response.status}): ${errorText}`);
      }

      const data = await response.json();
      console.log('✅ PayPal onboarding response:', data);

      if (data.success) {
        // Check if this is a mock response that auto-connected
        if (data.mockMode) {
          // Automatically refresh the connection status since it was auto-connected
          setTimeout(() => {
            checkPayPalConnection();
          }, 1000);
          
          alert('✅ PayPal connected successfully! (Mock connection for testing)');
          return;
        }
        
        // Real PayPal flow - open the onboarding window
        if (data.url) {
          window.open(data.url, '_blank', 'width=500,height=600,scrollbars=yes,resizable=yes');
          alert('✅ PayPal setup window opened! Complete the setup process and then refresh this page.');
          onClose();
        }
      } else {
        throw new Error(data.error || 'Failed to create PayPal onboarding link');
      }
    } catch (error) {
      console.error('Error connecting PayPal:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to connect PayPal';
      setPaypalError(errorMessage);
      
      // Also show alert for user feedback
      alert(`PayPal Connection Error: ${errorMessage}`);
    }
  };

  if (!isOpen) return null;

  const handleStartStream = async () => {
    if (!title.trim() || !user || !paypalConnected) return;
    
    setIsStarting(true);
    
    // Generate channel name
    const channelName = `stream_${user.id}_${Date.now()}`;
    
    try {
      await onStartStream({
        title: title.trim(),
        description: description.trim(),
        channelName,
      });
      
      // Reset form
      setTitle('');
      setDescription('');
      onClose();
    } catch (error) {
      console.error('Failed to start stream:', error);
    } finally {
      setIsStarting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-lg w-full max-w-md border border-gray-700 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Video className="text-red-500" size={24} />
            Go Live
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* PayPal Connection Status */}
          <div className="bg-gray-700 rounded-lg p-4">
            <h3 className="text-sm font-medium text-white mb-2 flex items-center gap-2">
              💳 Payment Setup Required
            </h3>
            
            {checkingPayPal ? (
              <div className="flex items-center gap-2 text-gray-300">
                <Loader2 size={16} className="animate-spin" />
                <span className="text-sm">Checking PayPal connection...</span>
              </div>
            ) : paypalConnected ? (
              <div className="flex items-center gap-2 text-green-400">
                <CheckCircle2 size={16} />
                <span className="text-sm">PayPal connected - ready to receive payments</span>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-red-400">
                  <AlertCircle size={16} />
                  <span className="text-sm">PayPal account required to go live</span>
                </div>
                
                {paypalError && (
                  <div className="text-xs text-red-300 bg-red-500/10 p-2 rounded">
                    {paypalError}
                  </div>
                )}
                
                <div className="text-xs text-gray-400 space-y-1">
                  <p>• Connect PayPal to receive auction payments</p>
                  <p>• Platform deducts 8% + $0.30 per transaction</p>
                  <p>• Payments processed instantly to your account</p>
                </div>
                
                <button
                  onClick={handleConnectPayPal}
                  className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-500 transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  <ExternalLink size={16} />
                  Connect PayPal Account
                </button>
              </div>
            )}
          </div>

          {/* Only show stream setup if PayPal is connected */}
          {paypalConnected && (
            <>
              {/* Title */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Stream Title *
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="What are you auctioning today?"
                  className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  maxLength={100}
                />
                <p className="text-xs text-gray-500 mt-1">{title.length}/100</p>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Description (Optional)
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Tell viewers about your items..."
                  className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none resize-none"
                  rows={3}
                  maxLength={500}
                />
                <p className="text-xs text-gray-500 mt-1">{description.length}/500</p>
              </div>

              {/* Thumbnail Upload (Placeholder) */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Thumbnail (Optional)
                </label>
                <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center">
                  <Image className="mx-auto text-gray-500 mb-2" size={32} />
                  <p className="text-sm text-gray-400">Upload a thumbnail image</p>
                </div>
              </div>

              {/* Stream Settings */}
              <div className="bg-gray-700 p-3 rounded-lg">
                <h3 className="text-sm font-medium text-white mb-2">Stream Settings</h3>
                <div className="space-y-2 text-sm text-gray-300">
                  <div className="flex justify-between">
                    <span>Quality:</span>
                    <span className="text-cyan-400">HD (720p)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Audio:</span>
                    <span className="text-cyan-400">Enabled</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Chat:</span>
                    <span className="text-cyan-400">Enabled</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Payments:</span>
                    <span className="text-green-400">PayPal Ready</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-700 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 bg-gray-700 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
          >
            Cancel
          </button>
          
          {paypalConnected ? (
            <button
              onClick={handleStartStream}
              disabled={!title.trim() || isStarting}
              className="flex-1 bg-red-500 text-white py-2 px-4 rounded-lg hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {isStarting ? (
                <>
                  <Loader2 size={16} className="animate-spin" />
                  Starting...
                </>
              ) : (
                <>
                  <Video size={16} />
                  Start Streaming
                </>
              )}
            </button>
          ) : (
            <button
              disabled
              className="flex-1 bg-gray-600 text-gray-400 py-2 px-4 rounded-lg cursor-not-allowed flex items-center justify-center gap-2"
            >
              <AlertCircle size={16} />
              Connect PayPal First
            </button>
          )}
        </div>
      </div>
    </div>
  );
}