import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Calendar, Clock, Bell, Users, Image, Plus, Edit, Trash2, Share, Copy } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../utils/supabase/info';

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

interface ScheduledStream {
  id: string;
  title: string;
  description: string;
  scheduledFor: number;
  heroImage?: string;
  sellerId: string;
  sellerName: string;
  status: 'scheduled' | 'live' | 'completed' | 'cancelled';
  remindersSent: number;
  subscriberCount: number;
  createdAt: number;
  landingPageUrl: string;
}

interface ScheduledStreamManagerProps {
  currentUserId: string;
  isSeller?: boolean;
  onStreamScheduled?: (stream: ScheduledStream) => void;
  className?: string;
}

export function ScheduledStreamManager({ 
  currentUserId, 
  isSeller = false, 
  onStreamScheduled,
  className = "" 
}: ScheduledStreamManagerProps) {
  const [scheduledStreams, setScheduledStreams] = useState<ScheduledStream[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedStream, setSelectedStream] = useState<ScheduledStream | null>(null);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [heroImage, setHeroImage] = useState('');

  // Load scheduled streams
  useEffect(() => {
    loadScheduledStreams();
    
    // Set up periodic checks for reminders
    const interval = setInterval(checkForReminders, 60000); // Check every minute
    
    return () => clearInterval(interval);
  }, [currentUserId]);

  const loadScheduledStreams = async () => {
    try {
      // In real implementation, this would fetch from database
      // For now, using mock data
      const mockStreams: ScheduledStream[] = [
        {
          id: '1',
          title: 'Rare Coral Collection Auction',
          description: 'Featuring premium SPS corals, rare zoanthids, and exotic fish from our latest collection.',
          scheduledFor: Date.now() + 3600000, // 1 hour from now
          heroImage: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400',
          sellerId: currentUserId,
          sellerName: 'Coral Paradise',
          status: 'scheduled',
          remindersSent: 0,
          subscriberCount: 23,
          createdAt: Date.now() - 86400000,
          landingPageUrl: `${window.location.origin}/show/1`
        }
      ];
      
      setScheduledStreams(mockStreams);
    } catch (error) {
      console.error('Failed to load scheduled streams:', error);
    }
  };

  const checkForReminders = async () => {
    const now = Date.now();
    
    scheduledStreams.forEach(async (stream) => {
      const timeUntilStream = stream.scheduledFor - now;
      const fifteenMinutes = 15 * 60 * 1000;
      
      // Send reminder 15 minutes before stream
      if (timeUntilStream <= fifteenMinutes && timeUntilStream > 0 && stream.remindersSent === 0) {
        await sendStreamReminder(stream);
      }
      
      // Auto-notify when stream goes live (simplified check)
      if (timeUntilStream <= 0 && stream.status === 'scheduled') {
        await notifyStreamLive(stream);
      }
    });
  };

  const sendStreamReminder = async (stream: ScheduledStream) => {
    try {
      console.log(`Sending 15-minute reminder for stream: ${stream.title}`);
      
      // In real implementation, this would:
      // 1. Send push notifications to subscribers
      // 2. Send email notifications
      // 3. Update the stream's remindersSent count
      
      // Update local state
      setScheduledStreams(prev => 
        prev.map(s => 
          s.id === stream.id 
            ? { ...s, remindersSent: s.remindersSent + 1 }
            : s
        )
      );
      
      // Show browser notification if supported
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`${stream.title} starts in 15 minutes!`, {
          body: stream.description,
          icon: stream.heroImage
        });
      }
    } catch (error) {
      console.error('Failed to send stream reminder:', error);
    }
  };

  const notifyStreamLive = async (stream: ScheduledStream) => {
    try {
      console.log(`Stream is now live: ${stream.title}`);
      
      // Update stream status
      setScheduledStreams(prev => 
        prev.map(s => 
          s.id === stream.id 
            ? { ...s, status: 'live' as const }
            : s
        )
      );
      
      // Notify followers
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`🔴 ${stream.title} is now LIVE!`, {
          body: 'Join now to start bidding on amazing items',
          icon: stream.heroImage
        });
      }
    } catch (error) {
      console.error('Failed to notify stream live:', error);
    }
  };

  const handleCreateStream = async () => {
    if (!title.trim() || !scheduledDate || !scheduledTime) return;
    
    try {
      setIsCreating(true);
      
      const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      const scheduledTimestamp = scheduledDateTime.getTime();
      
      const newStream: ScheduledStream = {
        id: Date.now().toString(),
        title: title.trim(),
        description: description.trim(),
        scheduledFor: scheduledTimestamp,
        heroImage: heroImage || 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400',
        sellerId: currentUserId,
        sellerName: 'Your Shop Name', // Would come from user profile
        status: 'scheduled',
        remindersSent: 0,
        subscriberCount: 0,
        createdAt: Date.now(),
        landingPageUrl: `${window.location.origin}/show/${Date.now()}`
      };
      
      setScheduledStreams(prev => [...prev, newStream]);
      onStreamScheduled?.(newStream);
      
      // Clear form
      setTitle('');
      setDescription('');
      setScheduledDate('');
      setScheduledTime('');
      setHeroImage('');
      setShowCreateModal(false);
      
      console.log('Stream scheduled successfully:', newStream);
    } catch (error) {
      console.error('Failed to schedule stream:', error);
    } finally {
      setIsCreating(false);
    }
  };

  const handleSubscribeToReminder = async (streamId: string) => {
    try {
      // In real implementation, this would:
      // 1. Add user to the stream's subscriber list
      // 2. Set up notifications for this user
      
      setScheduledStreams(prev => 
        prev.map(stream => 
          stream.id === streamId 
            ? { ...stream, subscriberCount: stream.subscriberCount + 1 }
            : stream
        )
      );
      
      console.log(`Subscribed to reminders for stream ${streamId}`);
      
      // Request notification permission if not granted
      if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
      }
    } catch (error) {
      console.error('Failed to subscribe to reminders:', error);
    }
  };

  const handleCopyLandingPage = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      console.log('Landing page URL copied to clipboard');
    } catch (error) {
      console.error('Failed to copy URL:', error);
    }
  };

  const formatDateTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      relative: getRelativeTime(timestamp)
    };
  };

  const getRelativeTime = (timestamp: number) => {
    const now = Date.now();
    const diff = timestamp - now;
    
    if (diff < 0) return 'Started';
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `in ${days} day${days > 1 ? 's' : ''}`;
    if (hours > 0) return `in ${hours} hour${hours > 1 ? 's' : ''}`;
    if (minutes > 0) return `in ${minutes} minute${minutes > 1 ? 's' : ''}`;
    return 'starting soon';
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      scheduled: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      live: 'bg-red-500/20 text-red-400 border-red-500/30',
      completed: 'bg-green-500/20 text-green-400 border-green-500/30',
      cancelled: 'bg-gray-500/20 text-gray-400 border-gray-500/30'
    };

    return (
      <Badge variant="outline" className={colors[status as keyof typeof colors]}>
        {status === 'live' && '🔴 '}
        {status.toUpperCase()}
      </Badge>
    );
  };

  // Get minimum date/time for scheduling (current time + 1 hour)
  const getMinDateTime = () => {
    const now = new Date();
    now.setHours(now.getHours() + 1);
    
    return {
      date: now.toISOString().split('T')[0],
      time: now.toTimeString().slice(0, 5)
    };
  };

  const minDateTime = getMinDateTime();

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header with Create Button */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Scheduled Shows</h2>
        {isSeller && (
          <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
            <DialogTrigger asChild>
              <Button className="bg-cyan-600 hover:bg-cyan-500">
                <Plus size={16} className="mr-2" />
                Schedule Show
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-900 border-gray-700 max-w-md">
              <DialogHeader>
                <DialogTitle className="text-white">Schedule New Show</DialogTitle>
                <DialogDescription className="text-gray-400">
                  Create a scheduled livestream auction for your followers
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 mt-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Show Title *</label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Amazing Coral Auction Night"
                    className="bg-gray-800 border-gray-600 text-white"
                    maxLength={100}
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Description</label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Tell your followers what to expect..."
                    className="bg-gray-800 border-gray-600 text-white resize-none"
                    rows={3}
                    maxLength={500}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">Date *</label>
                    <Input
                      type="date"
                      value={scheduledDate}
                      onChange={(e) => setScheduledDate(e.target.value)}
                      min={minDateTime.date}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">Time *</label>
                    <Input
                      type="time"
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      min={scheduledDate === minDateTime.date ? minDateTime.time : undefined}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Hero Image URL</label>
                  <Input
                    value={heroImage}
                    onChange={(e) => setHeroImage(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                
                <Button
                  onClick={handleCreateStream}
                  disabled={isCreating || !title.trim() || !scheduledDate || !scheduledTime}
                  className="w-full bg-cyan-600 hover:bg-cyan-500"
                >
                  {isCreating ? 'Scheduling...' : 'Schedule Show'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Scheduled Streams List */}
      <div className="space-y-4">
        {scheduledStreams.length > 0 ? (
          scheduledStreams.map((stream) => {
            const datetime = formatDateTime(stream.scheduledFor);
            const isOwner = stream.sellerId === currentUserId;
            
            return (
              <div key={stream.id} className="bg-gray-800 rounded-xl overflow-hidden">
                <div className="flex">
                  {/* Hero Image */}
                  <div className="w-32 h-32 flex-shrink-0">
                    <img 
                      src={stream.heroImage} 
                      alt={stream.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-bold text-white text-lg">{stream.title}</h3>
                        <p className="text-gray-400 text-sm">by {stream.sellerName}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(stream.status)}
                        {isOwner && (
                          <Button size="sm" variant="outline" className="border-gray-600">
                            <Edit size={14} />
                          </Button>
                        )}
                      </div>
                    </div>
                    
                    <p className="text-gray-300 text-sm mb-3 line-clamp-2">{stream.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1 text-cyan-400">
                          <Calendar size={14} />
                          <span>{datetime.date}</span>
                        </div>
                        <div className="flex items-center gap-1 text-cyan-400">
                          <Clock size={14} />
                          <span>{datetime.time}</span>
                        </div>
                        <div className="flex items-center gap-1 text-gray-400">
                          <Users size={14} />
                          <span>{stream.subscriberCount} reminders</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {stream.status === 'scheduled' && (
                          <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                            {datetime.relative}
                          </Badge>
                        )}
                        
                        {!isOwner && stream.status === 'scheduled' && (
                          <Button
                            size="sm"
                            onClick={() => handleSubscribeToReminder(stream.id)}
                            className="bg-blue-600 hover:bg-blue-500"
                          >
                            <Bell size={14} className="mr-1" />
                            Notify Me
                          </Button>
                        )}
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleCopyLandingPage(stream.landingPageUrl)}
                          className="border-gray-600 text-gray-300"
                        >
                          <Share size={14} className="mr-1" />
                          Share
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Countdown for upcoming streams */}
                {stream.status === 'scheduled' && (
                  <div className="px-4 py-2 bg-gray-700/50 border-t border-gray-700">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">
                        {stream.subscriberCount > 0 && `${stream.subscriberCount} people will be notified`}
                      </span>
                      <span className="text-cyan-400 font-medium">
                        {datetime.relative}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="text-center py-12 bg-gray-800 rounded-xl">
            <Calendar className="mx-auto text-gray-400 mb-4" size={48} />
            <h3 className="text-lg font-medium text-gray-300 mb-2">No Scheduled Shows</h3>
            <p className="text-gray-500 mb-4">
              {isSeller 
                ? "Schedule your first show to build anticipation with your followers" 
                : "Follow sellers to get notified about their upcoming shows"
              }
            </p>
            {isSeller && (
              <Button
                onClick={() => setShowCreateModal(true)}
                className="bg-cyan-600 hover:bg-cyan-500"
              >
                <Plus size={16} className="mr-2" />
                Schedule Your First Show
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}