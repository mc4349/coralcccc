import React, { useState, useEffect } from 'react';
import { supabase } from './utils/supabase/client';
import { Loader2, Home, Search, Video, Bell, User } from 'lucide-react';
import { AuthModal } from './components/AuthModal';
import { GoLiveModal } from './components/GoLiveModal';
import { AgoraLiveStream } from './components/AgoraLiveStream';
import { ScheduledStreamManager } from './components/ScheduledStreamManager';
import { projectId, publicAnonKey } from './utils/supabase/info';

// Type definitions
interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface StreamData {
  id: string;
  title: string;
  description: string;
  channelName: string;
  thumbnail?: string;
  host_name?: string;
  viewer_count?: number;
}

type Tab = 'home' | 'explore' | 'go-live' | 'live' | 'alerts' | 'account';

// Simple working components to avoid import issues
const SimpleHomeScreen = React.memo(({ user, onAuthRequired }: { user: User | null; onAuthRequired: () => void }) => {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-900 via-teal-900 to-blue-900 opacity-90"></div>
        <div className="relative px-4 py-16 md:py-24">
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Welcome to <span className="text-cyan-400">Coral Crave</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto">
              The premier livestream auction platform for the aquarium and reef community. 
              Discover rare corals, exotic fish, and premium equipment from trusted sellers worldwide.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => window.scrollTo({ top: window.innerHeight, behavior: 'smooth' })}
                className="bg-cyan-500 text-white px-8 py-4 rounded-lg hover:bg-cyan-400 transition-colors"
              >
                Explore Live Auctions
              </button>
              <button 
                onClick={onAuthRequired}
                className="bg-transparent border-2 border-cyan-400 text-cyan-400 px-8 py-4 rounded-lg hover:bg-cyan-400 hover:text-white transition-colors"
              >
                Start Selling
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Coral Crave?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">🔴</div>
              <h3 className="text-xl font-bold mb-3">Live Streaming</h3>
              <p className="text-gray-300">Real-time HD video streaming with low latency for the best auction experience</p>
            </div>
            
            <div className="bg-gray-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">💰</div>
              <h3 className="text-xl font-bold mb-3">Secure Payments</h3>
              <p className="text-gray-300">PayPal integration with buyer protection and seller-friendly fee structure</p>
            </div>
            
            <div className="bg-gray-800 rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">🌊</div>
              <h3 className="text-xl font-bold mb-3">Reef Community</h3>
              <p className="text-gray-300">Built specifically for aquarium enthusiasts by fellow reef keepers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Status Section */}
      {user && (
        <section className="py-16 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gray-800 rounded-xl p-8">
              <h2 className="text-2xl font-bold text-white mb-6">Welcome Back!</h2>
              
              <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                <h3 className="text-green-300 font-medium mb-2">✅ Account Active</h3>
                <p className="text-gray-300">Welcome back, {user.name}!</p>
                
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="bg-gray-700/30 rounded-lg p-3">
                    <h4 className="text-cyan-400 text-sm font-medium mb-1">🛒 As a Buyer</h4>
                    <p className="text-xs text-gray-300">Browse live auctions, place bids, win amazing coral specimens</p>
                  </div>
                  <div className="bg-gray-700/30 rounded-lg p-3">
                    <h4 className="text-cyan-400 text-sm font-medium mb-1">🐠 As a Seller</h4>
                    <p className="text-xs text-gray-300">Go live, showcase your corals, manage auction queues</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Call to Action */}
      {!user && (
        <section className="py-16 px-4 bg-gray-800/50">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-gray-300 mb-8">Join thousands of reef enthusiasts buying and selling through live auctions</p>
            <button 
              onClick={onAuthRequired}
              className="bg-cyan-500 text-white px-8 py-4 rounded-lg hover:bg-cyan-400 transition-colors"
            >
              Sign Up Today
            </button>
          </div>
        </section>
      )}
    </div>
  );
});

function SimpleExploreScreen({ onJoinStream }: { onJoinStream: (stream: StreamData) => void }) {
  const [liveStreams, setLiveStreams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState<'live' | 'scheduled'>('live');

  useEffect(() => {
    const fetchLiveStreams = async () => {
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/streams/list`, {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          setLiveStreams(data.streams || []);
        }
      } catch (error) {
        console.error('Failed to fetch live streams:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchLiveStreams();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchLiveStreams, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      {/* Header with Tabs */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-4">Discover Auctions</h1>
        
        {/* Tab Navigation */}
        <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg w-fit">
          <button
            onClick={() => setActiveView('live')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeView === 'live' 
                ? 'bg-red-500 text-white' 
                : 'text-gray-400 hover:text-white hover:bg-gray-700'
            }`}
          >
            🔴 Live Now
          </button>
          <button
            onClick={() => setActiveView('scheduled')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeView === 'scheduled' 
                ? 'bg-cyan-500 text-white' 
                : 'text-gray-400 hover:text-white hover:bg-gray-700'
            }`}
          >
            📅 Upcoming Shows
          </button>
        </div>
      </div>
      
      {/* Live Streams View */}
      {activeView === 'live' && (
        <>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
              <span className="ml-2 text-gray-400">Loading live streams...</span>
            </div>
          ) : liveStreams.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {liveStreams.map((stream) => (
                <div key={stream.id} className="bg-gray-800 rounded-xl overflow-hidden hover:bg-gray-750 transition-colors">
                  <div className="relative">
                    <div className="w-full h-48 bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center">
                      <span className="text-white text-lg">🪸 {stream.title}</span>
                    </div>
                    <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-sm font-medium">
                      🔴 LIVE
                    </div>
                    <div className="absolute top-2 right-2 bg-black/50 text-white px-2 py-1 rounded text-sm">
                      👥 {stream.viewer_count || 0}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold mb-2 truncate">{stream.title}</h3>
                    <p className="text-gray-400 text-sm mb-3 line-clamp-2">{stream.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500 text-sm truncate">by {stream.host_name}</span>
                      <button 
                        onClick={() => onJoinStream(stream)}
                        className="bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-600 transition-colors text-sm font-medium"
                      >
                        Join Live
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📺</div>
              <h2 className="text-2xl font-bold mb-4">No Live Streams</h2>
              <p className="text-gray-400 mb-6">No sellers are currently streaming. Check back soon or be the first to go live!</p>
            </div>
          )}
        </>
      )}

      {/* Scheduled Shows View */}
      {activeView === 'scheduled' && (
        <div className="max-w-6xl mx-auto">
          <ScheduledStreamManager 
            currentUserId="viewer"
            isSeller={false}
            className="mt-0"
          />
        </div>
      )}
    </div>
  );
}

function SimpleGoLiveScreen({ user, onAuthRequired }: { user: User | null; onAuthRequired: () => void }) {
  const [showGoLiveModal, setShowGoLiveModal] = useState(false);
  const [currentStream, setCurrentStream] = useState<any>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamStarting, setStreamStarting] = useState(false);
  const [activeView, setActiveView] = useState<'dashboard' | 'schedule'>('dashboard');

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔐</div>
          <h2 className="text-2xl font-bold mb-4">Authentication Required</h2>
          <p className="text-gray-400 mb-6">Please sign in to start streaming</p>
          <button 
            onClick={onAuthRequired}
            className="bg-cyan-500 hover:bg-cyan-600 px-6 py-3 rounded-lg"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const handleStartStream = async (streamData: { title: string; description: string; channelName: string; thumbnail?: string }) => {
    try {
      setStreamStarting(true);
      
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        throw new Error('Please sign in again to start streaming.');
      }
      
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/streams/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify(streamData)
      });

      if (!response.ok) {
        const errorText = await response.text();
        
        if (response.status === 401) {
          await supabase.auth.refreshSession();
          const { data: { session: freshSession } } = await supabase.auth.getSession();
          
          if (freshSession?.access_token && freshSession.access_token !== accessToken) {
            const retryResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/streams/start`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${freshSession.access_token}`
              },
              body: JSON.stringify(streamData)
            });
            
            if (retryResponse.ok) {
              const result = await retryResponse.json();
              setCurrentStream(result.stream);
              setIsStreaming(true);
              setShowGoLiveModal(false);
              return;
            }
          }
          
          throw new Error('Authentication failed. Please sign out and sign in again.');
        }
        
        throw new Error(`Failed to start stream: ${errorText}`);
      }

      const result = await response.json();
      setCurrentStream(result.stream);
      setIsStreaming(true);
      setShowGoLiveModal(false);
    } catch (error) {
      console.error('Failed to start stream:', error);
      alert(`Failed to start stream: ${error.message || error}`);
    } finally {
      setStreamStarting(false);
    }
  };

  const handleEndStream = () => {
    setIsStreaming(false);
    setCurrentStream(null);
  };

  // If currently streaming, show the live stream interface
  if (isStreaming && currentStream) {
    return (
      <AgoraLiveStream
        channelName={currentStream.id}
        isHost={true}
        onLeave={handleEndStream}
        userToken={user.id}
        forceRealCamera={true}
      />
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-900 text-white p-4">
        {/* Header with Tabs */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-4">Seller Dashboard</h1>
          
          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg w-fit">
            <button
              onClick={() => setActiveView('dashboard')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView === 'dashboard' 
                  ? 'bg-red-500 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              🔴 Go Live
            </button>
            <button
              onClick={() => setActiveView('schedule')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView === 'schedule' 
                  ? 'bg-cyan-500 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              📅 Schedule Shows
            </button>
          </div>
        </div>
        
        {/* Dashboard View */}
        {activeView === 'dashboard' && (
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-medium mb-2">Active Streams</h3>
                <p className="text-3xl font-bold text-cyan-400">0</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-medium mb-2">Total Viewers</h3>
                <p className="text-3xl font-bold text-green-400">0</p>
              </div>
              <div className="bg-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-medium mb-2">Products Ready</h3>
                <p className="text-3xl font-bold text-orange-400">0</p>
              </div>
            </div>

            {/* Go Live Section */}
            <div className="bg-gray-800 rounded-xl p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Ready to Go Live?</h2>
              <p className="text-gray-400 mb-6">Start streaming to showcase your products to buyers worldwide</p>
              
              <button 
                onClick={() => setShowGoLiveModal(true)}
                disabled={streamStarting}
                className="bg-red-500 hover:bg-red-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white px-8 py-4 rounded-lg text-lg font-medium transition-colors flex items-center gap-3 mx-auto"
              >
                {streamStarting ? (
                  <>
                    <Loader2 size={24} className="animate-spin" />
                    Starting Stream...
                  </>
                ) : (
                  <>
                    <Video size={24} />
                    🔴 Start Live Stream
                  </>
                )}
              </button>
            </div>

            {/* Tips and Best Practices */}
            <div className="bg-gray-800 rounded-xl p-6">
              <h3 className="text-xl font-bold mb-4">💡 Live Streaming Tips</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-cyan-400 font-medium mb-2">Before Going Live</h4>
                  <ul className="text-sm text-gray-300 space-y-1">
                    <li>• Test your camera and microphone</li>
                    <li>• Prepare your coral collection</li>
                    <li>• Ensure good lighting setup</li>
                    <li>• Have product details ready</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-cyan-400 font-medium mb-2">During the Stream</h4>
                  <ul className="text-sm text-gray-300 space-y-1">
                    <li>• Engage with viewers in chat</li>
                    <li>• Show products clearly</li>
                    <li>• Set clear bidding rules</li>
                    <li>• Keep energy high and positive</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Schedule View */}
        {activeView === 'schedule' && (
          <div className="max-w-6xl mx-auto">
            <ScheduledStreamManager 
              currentUserId={user.id}
              isSeller={true}
              className="mt-0"
            />
          </div>
        )}
      </div>

      {/* Go Live Modal */}
      {showGoLiveModal && (
        <GoLiveModal
          isOpen={showGoLiveModal}
          onClose={() => setShowGoLiveModal(false)}
          onStartStream={handleStartStream}
          user={user}
        />
      )}
    </>
  );
}

function SimpleAlertsScreen({ user, onAuthRequired }: { user: User | null; onAuthRequired: () => void }) {
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4">
        <div className="text-center py-12">
          <Bell className="mx-auto text-gray-400 mb-4" size={64} />
          <h2 className="text-2xl font-bold text-gray-300 mb-2">Stay Updated</h2>
          <p className="text-gray-500 mb-6">Sign in to receive alerts about your bids and auctions</p>
          <button
            onClick={onAuthRequired}
            className="bg-cyan-500 text-white px-6 py-3 rounded-lg hover:bg-cyan-400 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <h1 className="text-3xl font-bold mb-6">Notifications</h1>
      
      <div className="max-w-4xl mx-auto">
        <div className="text-center py-12">
          <Bell className="mx-auto text-gray-400 mb-4" size={64} />
          <h2 className="text-xl font-bold text-gray-300 mb-2">No New Notifications</h2>
          <p className="text-gray-500">When you participate in auctions, you'll see updates here</p>
        </div>
      </div>
    </div>
  );
}

function SimpleAccountScreen({ user, onAuthRequired }: { user: User | null; onAuthRequired: () => void }) {
  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Logout error:', error);
        alert('Failed to log out. Please try again.');
      }
    } catch (error) {
      console.error('Logout exception:', error);
      alert('Failed to log out. Please try again.');
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4">
        <div className="text-center py-12">
          <User className="mx-auto text-gray-400 mb-4" size={64} />
          <h2 className="text-2xl font-bold text-gray-300 mb-2">Account Management</h2>
          <p className="text-gray-500 mb-6">Sign in to access your account settings and purchase history</p>
          <button
            onClick={onAuthRequired}
            className="bg-cyan-500 text-white px-6 py-3 rounded-lg hover:bg-cyan-400 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <h1 className="text-3xl font-bold mb-6">My Account</h1>
      
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Profile Section */}
        <div className="bg-gray-800 rounded-xl p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-bold">Profile Information</h2>
            <button
              onClick={handleLogout}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
            >
              Sign Out
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Name</label>
              <input 
                type="text" 
                value={user.name} 
                readOnly
                className="w-full bg-gray-700 rounded-lg px-3 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <input 
                type="email" 
                value={user.email} 
                readOnly
                className="w-full bg-gray-700 rounded-lg px-3 py-2 text-white"
              />
            </div>
          </div>
        </div>

        {/* Purchase History */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-bold mb-4">Recent Purchases</h2>
          <p className="text-gray-400">No purchases yet. Start bidding to see your history here!</p>
        </div>

        {/* Seller Stats */}
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-bold mb-4">Seller Statistics</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-400">$0</p>
              <p className="text-gray-400">Total Sales</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-400">0</p>
              <p className="text-gray-400">Items Sold</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-cyan-400">5.0</p>
              <p className="text-gray-400">Rating</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Loading fallback component
function LoadingFallback({ text = "Loading..." }: { text?: string }) {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400 mx-auto mb-4" />
        <p className="text-gray-300">{text}</p>
      </div>
    </div>
  );
}

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [currentLiveStream, setCurrentLiveStream] = useState<any>(null);

  // Auth modal handler
  const handleAuthRequired = () => {
    setShowAuthModal(true);
  };

  // Stream join handler
  const handleJoinStream = (stream: StreamData) => {
    setCurrentLiveStream(stream);
    setActiveTab('live');
  };

  // Stream leave handler  
  const handleLeaveStream = () => {
    setCurrentLiveStream(null);
    setActiveTab('explore');
  };
  
  useEffect(() => {
    // Check for existing session
    const checkSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          setUser({
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata?.name || session.user.email || 'User'
          });
        }
      } catch (error) {
        console.warn('Session check error:', error);
      } finally {
        setLoading(false);
      }
    };

    checkSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        setUser({
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.name || session.user.email || 'User'
        });
        setShowAuthModal(false);
      } else {
        setUser(null);
      }
    });

    return () => {
      try { 
        subscription?.unsubscribe(); 
      } catch (error) {
        console.warn('Error unsubscribing from auth changes:', error);
      }
    };
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <SimpleHomeScreen user={user} onAuthRequired={handleAuthRequired} />;
      case 'explore':
        return <SimpleExploreScreen onJoinStream={handleJoinStream} />;
      case 'go-live':
        return <SimpleGoLiveScreen user={user} onAuthRequired={handleAuthRequired} />;
      case 'live':
        // If viewing a specific live stream, show the viewer interface
        if (currentLiveStream) {
          return (
            <AgoraLiveStream
              channelName={currentLiveStream.id}
              isHost={false}
              onLeave={handleLeaveStream}
              userToken={user?.id || 'viewer'}
              forceRealCamera={true}
            />
          );
        }
        // Otherwise show the default live tab content
        return (
          <div className="min-h-screen bg-gray-900 text-white p-4">
            <h1 className="text-3xl font-bold mb-4">Live Stream</h1>
            <p className="text-gray-400">Join a live stream from the Explore section to start watching!</p>
          </div>
        );
      case 'alerts':
        return <SimpleAlertsScreen user={user} onAuthRequired={handleAuthRequired} />;
      case 'account':
        return <SimpleAccountScreen user={user} onAuthRequired={handleAuthRequired} />;
      default:
        return <SimpleHomeScreen user={user} onAuthRequired={handleAuthRequired} />;
    }
  };

  if (loading) {
    return <LoadingFallback text="Loading Coral Crave..." />;
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Desktop Sidebar */}
      <div className="hidden md:block fixed left-0 top-0 h-full w-64 bg-gray-800/95 backdrop-blur-sm border-r border-gray-700 z-40">
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-8">
            <div className="text-3xl">🪸</div>
            <div>
              <h1 className="text-xl font-bold text-cyan-400">Coral Crave</h1>
              <p className="text-xs text-gray-400">Live Auction Platform</p>
            </div>
          </div>
          
          {/* Status Indicator */}
          <div className="mb-6 p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm text-green-300">Platform Online</span>
            </div>
            {user ? (
              <p className="text-xs text-gray-400">Welcome, {user.name}</p>
            ) : (
              <p className="text-xs text-gray-400">Sign in to get started</p>
            )}
          </div>
          
          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('home')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'home' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Home size={20} className="mr-3" />
              Home
            </button>
            
            <button
              onClick={() => setActiveTab('explore')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'explore' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Search size={20} className="mr-3" />
              Explore Auctions
            </button>

            <button
              onClick={() => setActiveTab('go-live')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'go-live' ? 'bg-red-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Video size={20} className="mr-3" />
              Go Live
            </button>

            <button
              onClick={() => setActiveTab('alerts')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'alerts' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Bell size={20} className="mr-3" />
              Notifications
            </button>

            <button
              onClick={() => setActiveTab('account')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'account' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <User size={20} className="mr-3" />
              My Account
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="md:ml-64 min-h-screen">
        <div className="pb-20 md:pb-0">
          {renderContent()}
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-800/95 backdrop-blur-sm border-t border-gray-700 md:hidden z-50">
        <div className="flex items-center justify-around py-2">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'home' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Home size={20} />
            <span className="text-xs mt-1">Home</span>
          </button>
          
          <button
            onClick={() => setActiveTab('explore')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'explore' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Search size={20} />
            <span className="text-xs mt-1">Explore</span>
          </button>

          <button
            onClick={() => setActiveTab('go-live')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'go-live' ? 'text-red-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Video size={20} />
            <span className="text-xs mt-1">Go Live</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'alerts' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Bell size={20} />
            <span className="text-xs mt-1">Alerts</span>
          </button>

          <button
            onClick={() => setActiveTab('account')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'account' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <User size={20} />
            <span className="text-xs mt-1">Account</span>
          </button>
        </div>
      </div>

      {/* Authentication Modal */}
      {showAuthModal && (
        <AuthModal onClose={() => setShowAuthModal(false)} />
      )}
    </div>
  );
}

export default App;