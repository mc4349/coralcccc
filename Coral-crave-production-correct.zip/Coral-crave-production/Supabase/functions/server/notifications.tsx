import { Hono } from 'npm:hono'

interface Notification {
  id: string;
  userId: string;
  type: 'outbid' | 'auction_ending' | 'auction_won' | 'new_item' | 'price_drop' | 'payment_required' | 'system';
  itemId?: string;
  sellerId?: string;
  title: string;
  message: string;
  data?: any;
  read: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  createdAt: string;
  expiresAt?: string;
}

interface NotificationPreferences {
  userId: string;
  outbidAlerts: boolean;
  auctionEndingAlerts: boolean;
  newItemAlerts: boolean;
  priceDropAlerts: boolean;
  systemAlerts: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  quietHours: {
    enabled: boolean;
    startTime: string;
    endTime: string;
  };
}

// Real-time Notifications System
export function createNotificationRoutes(app: Hono, supabase: any) {
  
  // Get user notifications
  app.get('/make-server-9f7745d8/notifications/:userId', async (c) => {
    try {
      const userId = c.req.param('userId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user || user.id !== userId) {
        return c.json({ error: 'Unauthorized access to notifications' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const notifications = await kvModule.get(`notifications:${userId}`) || [];
      
      // Filter out expired notifications
      const now = new Date().toISOString();
      const validNotifications = notifications.filter((n: Notification) => 
        !n.expiresAt || n.expiresAt > now
      );

      // Update if any were filtered
      if (validNotifications.length !== notifications.length) {
        await kvModule.set(`notifications:${userId}`, validNotifications);
      }

      return c.json({
        success: true,
        notifications: validNotifications,
        unreadCount: validNotifications.filter((n: Notification) => !n.read).length
      });

    } catch (error) {
      console.error('Notifications fetch error:', error);
      return c.json({ 
        error: 'Failed to fetch notifications', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Mark notification as read
  app.patch('/make-server-9f7745d8/notifications/:notificationId/read', async (c) => {
    try {
      const notificationId = c.req.param('notificationId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const notifications = await kvModule.get(`notifications:${user.id}`) || [];
      
      const updatedNotifications = notifications.map((n: Notification) => 
        n.id === notificationId ? { ...n, read: true } : n
      );

      await kvModule.set(`notifications:${user.id}`, updatedNotifications);

      return c.json({
        success: true,
        message: 'Notification marked as read'
      });

    } catch (error) {
      console.error('Mark notification read error:', error);
      return c.json({ 
        error: 'Failed to mark notification as read', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Mark all notifications as read
  app.patch('/make-server-9f7745d8/notifications/:userId/read-all', async (c) => {
    try {
      const userId = c.req.param('userId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user || user.id !== userId) {
        return c.json({ error: 'Unauthorized access to notifications' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const notifications = await kvModule.get(`notifications:${userId}`) || [];
      
      const updatedNotifications = notifications.map((n: Notification) => ({ ...n, read: true }));
      await kvModule.set(`notifications:${userId}`, updatedNotifications);

      return c.json({
        success: true,
        message: 'All notifications marked as read'
      });

    } catch (error) {
      console.error('Mark all notifications read error:', error);
      return c.json({ 
        error: 'Failed to mark all notifications as read', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Delete notification
  app.delete('/make-server-9f7745d8/notifications/:notificationId', async (c) => {
    try {
      const notificationId = c.req.param('notificationId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const notifications = await kvModule.get(`notifications:${user.id}`) || [];
      
      const updatedNotifications = notifications.filter((n: Notification) => n.id !== notificationId);
      await kvModule.set(`notifications:${user.id}`, updatedNotifications);

      return c.json({
        success: true,
        message: 'Notification deleted'
      });

    } catch (error) {
      console.error('Delete notification error:', error);
      return c.json({ 
        error: 'Failed to delete notification', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Get notification preferences
  app.get('/make-server-9f7745d8/notifications/:userId/preferences', async (c) => {
    try {
      const userId = c.req.param('userId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user || user.id !== userId) {
        return c.json({ error: 'Unauthorized access to preferences' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      const preferences = await kvModule.get(`notification_preferences:${userId}`) || getDefaultPreferences(userId);

      return c.json({
        success: true,
        preferences
      });

    } catch (error) {
      console.error('Notification preferences fetch error:', error);
      return c.json({ 
        error: 'Failed to fetch notification preferences', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Update notification preferences
  app.put('/make-server-9f7745d8/notifications/:userId/preferences', async (c) => {
    try {
      const userId = c.req.param('userId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user || user.id !== userId) {
        return c.json({ error: 'Unauthorized access to preferences' }, 401);
      }

      const preferences = await c.req.json();
      const kvModule = await import('./kv_store.tsx');
      
      const updatedPreferences: NotificationPreferences = {
        userId,
        ...preferences
      };

      await kvModule.set(`notification_preferences:${userId}`, updatedPreferences);

      return c.json({
        success: true,
        preferences: updatedPreferences,
        message: 'Notification preferences updated'
      });

    } catch (error) {
      console.error('Update notification preferences error:', error);
      return c.json({ 
        error: 'Failed to update notification preferences', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Follow seller for notifications
  app.post('/make-server-9f7745d8/follow/:sellerId', async (c) => {
    try {
      const sellerId = c.req.param('sellerId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      if (user.id === sellerId) {
        return c.json({ error: 'Cannot follow yourself' }, 400);
      }

      const kvModule = await import('./kv_store.tsx');
      
      // Add to user's following list
      const userFollowing = await kvModule.get(`following:${user.id}`) || [];
      if (!userFollowing.includes(sellerId)) {
        userFollowing.push(sellerId);
        await kvModule.set(`following:${user.id}`, userFollowing);
      }

      // Add to seller's followers list
      const sellerFollowers = await kvModule.get(`followers:${sellerId}`) || [];
      if (!sellerFollowers.includes(user.id)) {
        sellerFollowers.push(user.id);
        await kvModule.set(`followers:${sellerId}`, sellerFollowers);
      }

      return c.json({
        success: true,
        message: 'Successfully followed seller'
      });

    } catch (error) {
      console.error('Follow seller error:', error);
      return c.json({ 
        error: 'Failed to follow seller', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Unfollow seller
  app.delete('/make-server-9f7745d8/follow/:sellerId', async (c) => {
    try {
      const sellerId = c.req.param('sellerId');
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      const kvModule = await import('./kv_store.tsx');
      
      // Remove from user's following list
      const userFollowing = await kvModule.get(`following:${user.id}`) || [];
      const updatedFollowing = userFollowing.filter((id: string) => id !== sellerId);
      await kvModule.set(`following:${user.id}`, updatedFollowing);

      // Remove from seller's followers list
      const sellerFollowers = await kvModule.get(`followers:${sellerId}`) || [];
      const updatedFollowers = sellerFollowers.filter((id: string) => id !== user.id);
      await kvModule.set(`followers:${sellerId}`, updatedFollowers);

      return c.json({
        success: true,
        message: 'Successfully unfollowed seller'
      });

    } catch (error) {
      console.error('Unfollow seller error:', error);
      return c.json({ 
        error: 'Failed to unfollow seller', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });

  // Send test notification
  app.post('/make-server-9f7745d8/notifications/test', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1];
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401);
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken);
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401);
      }

      await sendNotification(user.id, {
        type: 'system',
        title: 'Test Notification',
        message: 'This is a test notification to verify your settings.',
        priority: 'low'
      });

      return c.json({
        success: true,
        message: 'Test notification sent'
      });

    } catch (error) {
      console.error('Send test notification error:', error);
      return c.json({ 
        error: 'Failed to send test notification', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500);
    }
  });
}

// Notification Utility Functions
export async function sendNotification(userId: string, notificationData: Partial<Notification>) {
  try {
    const kvModule = await import('./kv_store.tsx');
    
    // Check user preferences
    const preferences = await kvModule.get(`notification_preferences:${userId}`) || getDefaultPreferences(userId);
    
    // Check if this type of notification is enabled
    const typeEnabled = isNotificationTypeEnabled(notificationData.type!, preferences);
    if (!typeEnabled) {
      console.log('🔕 Notification type disabled for user:', userId, notificationData.type);
      return;
    }

    // Check quiet hours
    if (preferences.quietHours.enabled && isInQuietHours(preferences.quietHours)) {
      // Schedule for later or skip non-urgent notifications
      if (notificationData.priority !== 'urgent') {
        console.log('🔕 Skipping non-urgent notification during quiet hours');
        return;
      }
    }

    const notificationId = `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const notification: Notification = {
      id: notificationId,
      userId,
      type: notificationData.type || 'system',
      itemId: notificationData.itemId,
      sellerId: notificationData.sellerId,
      title: notificationData.title || 'Coral Crave Notification',
      message: notificationData.message || '',
      data: notificationData.data,
      read: false,
      priority: notificationData.priority || 'medium',
      createdAt: new Date().toISOString(),
      expiresAt: notificationData.expiresAt
    };

    // Add to user's notifications
    const userNotifications = await kvModule.get(`notifications:${userId}`) || [];
    userNotifications.unshift(notification);
    
    // Keep only latest 100 notifications
    const trimmedNotifications = userNotifications.slice(0, 100);
    await kvModule.set(`notifications:${userId}`, trimmedNotifications);

    console.log('📢 Notification sent to user:', userId, notification.type);
    
    return notification;
  } catch (error) {
    console.error('Send notification error:', error);
  }
}

export async function sendAuctionEndingWarning(itemId: string, timeLeft: number) {
  try {
    const kvModule = await import('./kv_store.tsx');
    const auction = await kvModule.get(`active_auction:${itemId}`);
    
    if (!auction) return;

    const bidHistory = await kvModule.get(`bid_history:${itemId}`) || [];
    const uniqueBidders = [...new Set(bidHistory.map((bid: any) => bid.userId))];
    
    const warningMessage = timeLeft <= 60 ? 
      `⚠️ Less than 1 minute left!` : 
      `⚠️ ${Math.floor(timeLeft / 60)} minutes left`;

    for (const bidderId of uniqueBidders) {
      await sendNotification(bidderId, {
        type: 'auction_ending',
        itemId,
        title: `Auction Ending Soon: ${auction.title}`,
        message: `${warningMessage} Current bid: $${auction.currentBid}`,
        priority: timeLeft <= 60 ? 'urgent' : 'high',
        expiresAt: new Date(Date.now() + timeLeft * 1000).toISOString()
      });
    }

    console.log('⏰ Auction ending warnings sent to', uniqueBidders.length, 'bidders');
  } catch (error) {
    console.error('Send auction ending warning error:', error);
  }
}

function getDefaultPreferences(userId: string): NotificationPreferences {
  return {
    userId,
    outbidAlerts: true,
    auctionEndingAlerts: true,
    newItemAlerts: true,
    priceDropAlerts: false,
    systemAlerts: true,
    emailNotifications: false,
    pushNotifications: true,
    quietHours: {
      enabled: false,
      startTime: '22:00',
      endTime: '08:00'
    }
  };
}

function isNotificationTypeEnabled(type: string, preferences: NotificationPreferences): boolean {
  switch (type) {
    case 'outbid':
      return preferences.outbidAlerts;
    case 'auction_ending':
      return preferences.auctionEndingAlerts;
    case 'new_item':
      return preferences.newItemAlerts;
    case 'price_drop':
      return preferences.priceDropAlerts;
    case 'system':
    case 'payment_required':
    case 'auction_won':
      return preferences.systemAlerts;
    default:
      return true;
  }
}

function isInQuietHours(quietHours: { startTime: string; endTime: string }): boolean {
  const now = new Date();
  const currentTime = now.getHours() * 100 + now.getMinutes();
  
  const startTime = parseInt(quietHours.startTime.replace(':', ''));
  const endTime = parseInt(quietHours.endTime.replace(':', ''));
  
  if (startTime < endTime) {
    return currentTime >= startTime && currentTime <= endTime;
  } else {
    // Quiet hours span midnight
    return currentTime >= startTime || currentTime <= endTime;
  }
}