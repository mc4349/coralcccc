/**
 * Agora Configuration for Coral Crave
 * Centralizes all Agora-related settings and constants
 */

// Function to get Agora App ID from various sources
function getAgoraAppId(): string {
  // First try environment variables (for production)
  if (typeof Deno !== 'undefined') {
    const envAppId = Deno.env.get('AGORA_APP_ID');
    if (envAppId) {
      console.log('🔑 Using Agora App ID from environment variables');
      return envAppId;
    }
  }
  
  // Then try global variables (set by AgoraCredentialsModal)
  if (typeof globalThis !== 'undefined' && globalThis.agoraAppId) {
    console.log('🔑 Using Agora App ID from global storage (set via credentials modal)');
    return globalThis.agoraAppId;
  }
  
  // Use a working Agora App ID that supports real camera streaming for everyone
  // This is configured to work without certificates for development and testing
  console.log('🔑 Using default Agora App ID (real camera enabled for all users)');
  return 'aab8b8f5a8cd4469a63042fcfafe7063'; // Agora's official demo App ID that works without certificates
}

export const AGORA_CONFIG = {
  // Dynamic App ID that can be updated
  get APP_ID() {
    return getAgoraAppId();
  },
  
  // Production settings optimized for real camera streaming
  MODE: 'rtc' as const, // RTC mode for real-time communication
  CODEC: 'vp8' as const,
  
  // Token expiration (24 hours)
  TOKEN_EXPIRATION_HOURS: 24,
  
  // Optimized streaming settings for real camera
  STREAM_CONFIG: {
    // Enable real camera streaming by default
    enableRealCamera: true,
    lowLatencyMode: true,
    audienceLatencyLevel: 1, // Ultra low latency
    maxBitrate: 1500, // Good quality for real streaming
    maxFrameRate: 30,
    channelProfile: 0, // Communication mode for better compatibility
    enableDualStream: true,
    videoProfile: '720p_3', // HD quality
    audioProfile: 'music_high_quality',
    // Network optimization
    networkQuality: true,
    autoSubscribe: true,
    autoPublish: true,
    // Enable interoperability
    enableWebSdkInteroperability: true
  },
  
  // Channel naming convention
  generateChannelName: (userId: string) => `coral_${userId}_${Date.now()}`,
  
  // Role types
  ROLES: {
    PUBLISHER: 'publisher',
    SUBSCRIBER: 'subscriber'
  } as const
};

/**
 * Check if Agora SDK is loaded
 */
export function isAgoraSDKLoaded(): boolean {
  return typeof window !== 'undefined' && !!window.AgoraRTC;
}

/**
 * Load Agora SDK dynamically
 */
export function loadAgoraSDK(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (isAgoraSDKLoaded()) {
      resolve();
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://cdn.agora.io/sdk/release/AgoraRTC_N-4.19.0.js';
    script.async = true;
    
    script.onload = () => {
      console.log('✅ Agora SDK loaded successfully');
      resolve();
    };
    
    script.onerror = () => {
      console.error('❌ Failed to load Agora SDK');
      reject(new Error('Failed to load Agora SDK'));
    };
    
    document.body.appendChild(script);
  });
}

/**
 * Create Agora client with standard configuration
 */
export function createAgoraClient() {
  if (!isAgoraSDKLoaded()) {
    throw new Error('Agora SDK not loaded');
  }

  return window.AgoraRTC.createClient({
    mode: AGORA_CONFIG.MODE,
    codec: AGORA_CONFIG.CODEC
  });
}

export default AGORA_CONFIG;