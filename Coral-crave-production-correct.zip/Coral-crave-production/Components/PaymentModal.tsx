import React, { useState } from 'react';
import { X, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { PayPalCheckout } from './PayPalCheckout';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface PaymentModalProps {
  isOpen: boolean;
  onClose?: () => void; // Made optional since it should be blocking
  auctionItem: {
    id: string;
    title: string;
    image: string;
    winningBid: number;
    sellerId: string;
    sellerName: string;
  };
  buyerId: string;
  onPaymentSuccess: (paymentId: string) => void;
  isBlocking?: boolean; // Add blocking mode
}

export function PaymentModal({ 
  isOpen, 
  onClose, 
  auctionItem, 
  buyerId, 
  onPaymentSuccess 
}: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'paypal' | 'card'>('paypal');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handlePayPalSuccess = async (paymentId: string) => {
    setIsProcessing(true);
    setError(null);

    try {
      // Process the payment and generate invoice
      const response = await fetch(`https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/process-auction-payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${window.supabase?.supabaseKey}`
        },
        body: JSON.stringify({
          auctionItemId: auctionItem.id,
          buyerId,
          paymentId,
          winningBid: auctionItem.winningBid,
          sellerId: auctionItem.sellerId
        })
      });

      if (!response.ok) {
        throw new Error('Payment processing failed');
      }

      const result = await response.json();
      
      setPaymentComplete(true);
      setTimeout(() => {
        onPaymentSuccess(paymentId);
        if (onClose) onClose();
      }, 2000);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payment processing failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCardPayment = async () => {
    setIsProcessing(true);
    setError(null);

    try {
      // Implement card payment processing here
      // For now, simulate success
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockPaymentId = `card_${Date.now()}`;
      await handlePayPalSuccess(mockPaymentId);
      
    } catch (err) {
      setError('Card payment failed. Please try again.');
      setIsProcessing(false);
    }
  };

  if (paymentComplete) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardContent className="p-6 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Payment Successful!</h3>
            <p className="text-gray-300 mb-4">
              Your payment has been processed and an invoice has been sent to your email.
            </p>
            <p className="text-sm text-cyan-400">
              Shipping will be calculated and billed separately after the stream ends.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-lg bg-gray-800 border-gray-700 max-h-[90vh] overflow-y-auto">
        <CardHeader className="border-b border-gray-700">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-semibold text-white">
              🎉 Congratulations!
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
          <p className="text-gray-300">You've won this auction!</p>
        </CardHeader>

        <CardContent className="p-6">
          {/* Item Details */}
          <div className="flex items-start space-x-4 mb-6">
            <ImageWithFallback
              src={auctionItem.image}
              alt={auctionItem.title}
              className="w-20 h-20 object-cover rounded-lg"
            />
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-1">{auctionItem.title}</h3>
              <p className="text-sm text-gray-400">Sold by {auctionItem.sellerName}</p>
              <div className="mt-2">
                <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                  Winning Bid: ${auctionItem.winningBid.toFixed(2)}
                </Badge>
              </div>
            </div>
          </div>

          {/* Payment Amount */}
          <div className="bg-gray-700 rounded-lg p-4 mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-300">Your Total:</span>
              <span className="text-2xl font-bold text-white">
                ${auctionItem.winningBid.toFixed(2)}
              </span>
            </div>
            <p className="text-sm text-cyan-400">
              💡 Shipping will be billed separately after the stream
            </p>
          </div>

          {/* Payment Method Selection */}
          <div className="mb-6">
            <h4 className="font-medium text-white mb-3">Choose Payment Method</h4>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setPaymentMethod('paypal')}
                className={`p-3 rounded-lg border-2 transition-colors ${
                  paymentMethod === 'paypal'
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400'
                    : 'border-gray-600 bg-gray-700 text-gray-300 hover:border-gray-500'
                }`}
              >
                <div className="flex items-center justify-center space-x-2">
                  <span className="font-medium">PayPal</span>
                </div>
              </button>
              
              <button
                onClick={() => setPaymentMethod('card')}
                className={`p-3 rounded-lg border-2 transition-colors ${
                  paymentMethod === 'card'
                    ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400'
                    : 'border-gray-600 bg-gray-700 text-gray-300 hover:border-gray-500'
                }`}
              >
                <div className="flex items-center justify-center space-x-2">
                  <CreditCard className="w-4 h-4" />
                  <span className="font-medium">Card</span>
                </div>
              </button>
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3 mb-4">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <span className="text-red-400 text-sm">{error}</span>
              </div>
            </div>
          )}

          {/* Payment Button */}
          {paymentMethod === 'paypal' ? (
            <div className="w-full">
              <PayPalCheckout
                amount={auctionItem.winningBid}
                onSuccess={handlePayPalSuccess}
                onError={(error) => setError(error)}
                disabled={isProcessing}
              />
            </div>
          ) : (
            <Button
              onClick={handleCardPayment}
              disabled={isProcessing}
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-white"
            >
              {isProcessing ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Processing...</span>
                </div>
              ) : (
                <>
                  <CreditCard className="w-4 h-4 mr-2" />
                  Pay ${auctionItem.winningBid.toFixed(2)} with Card
                </>
              )}
            </Button>
          )}

          {/* Footer Note */}
          <p className="text-xs text-gray-400 text-center mt-4">
            By completing this payment, you agree to our Terms of Service.
            An invoice will be automatically generated and sent to your email.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}