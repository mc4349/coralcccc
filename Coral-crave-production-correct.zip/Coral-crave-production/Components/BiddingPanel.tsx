import React, { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Clock, Gavel, TrendingUp, Users, DollarSign, AlertCircle, Zap } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../utils/supabase/info';

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

interface BiddingPanelProps {
  auctionItem: {
    id: string;
    title: string;
    description: string;
    startingPrice: number;
    currentPrice: number;
    timeLeft: number;
    endTime: number;
    image: string;
    bids: Array<{
      id: string;
      amount: number;
      bidder: string;
      timestamp: number;
    }>;
  } | null;
  onPlaceBid: (amount: number) => Promise<void>;
  currentUserId?: string;
  isHost?: boolean;
  className?: string;
}

export function BiddingPanel({ 
  auctionItem, 
  onPlaceBid, 
  currentUserId, 
  isHost = false,
  className = "" 
}: BiddingPanelProps) {
  const [bidAmount, setBidAmount] = useState('');
  const [maxBid, setMaxBid] = useState('');
  const [isPlacingBid, setIsPlacingBid] = useState(false);
  const [lastBidTime, setLastBidTime] = useState<number | null>(null);
  const [softCloseExtensions, setSoftCloseExtensions] = useState(0);
  const [showExtensionBadge, setShowExtensionBadge] = useState(false);
  const [currentTimeLeft, setCurrentTimeLeft] = useState(0);
  const extensionTimeoutRef = useRef<NodeJS.Timeout>();

  // Update time left with soft close logic
  useEffect(() => {
    if (!auctionItem) return;
    
    const updateTimer = () => {
      const now = Date.now();
      const timeRemaining = Math.max(0, auctionItem.endTime - now);
      setCurrentTimeLeft(timeRemaining);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 100); // Update every 100ms for smooth countdown

    return () => clearInterval(interval);
  }, [auctionItem?.endTime]);

  // Handle soft close extension
  useEffect(() => {
    if (!auctionItem || !lastBidTime) return;

    const timeSinceBid = Date.now() - lastBidTime;
    const timeWhenBidPlaced = currentTimeLeft + timeSinceBid;

    // If bid was placed with ≤10 seconds remaining, extend by 10 seconds
    if (timeWhenBidPlaced <= 10000) {
      setSoftCloseExtensions(prev => prev + 1);
      setShowExtensionBadge(true);
      
      // Update the auction end time
      auctionItem.endTime = auctionItem.endTime + 10000;

      // Hide extension badge after 3 seconds
      if (extensionTimeoutRef.current) {
        clearTimeout(extensionTimeoutRef.current);
      }
      extensionTimeoutRef.current = setTimeout(() => {
        setShowExtensionBadge(false);
      }, 3000);
    }
  }, [lastBidTime, currentTimeLeft, auctionItem]);

  const formatTime = (ms: number) => {
    if (ms <= 0) return '00:00';
    
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const getMinimumBid = () => {
    if (!auctionItem) return 0;
    return auctionItem.currentPrice + 1;
  };

  const handlePresetBid = async (increment: number) => {
    if (isHost) return; // Hosts cannot bid
    
    const newBidAmount = auctionItem!.currentPrice + increment;
    await handlePlaceBid(newBidAmount);
  };

  const handleMaxBid = async () => {
    if (isHost || !maxBid) return;
    
    const amount = parseFloat(maxBid);
    if (amount >= getMinimumBid()) {
      await handlePlaceBid(amount);
      setMaxBid('');
    }
  };

  const handleCustomBid = async () => {
    if (isHost || !bidAmount) return;
    
    const amount = parseFloat(bidAmount);
    if (amount >= getMinimumBid()) {
      await handlePlaceBid(amount);
      setBidAmount('');
    }
  };

  const handlePlaceBid = async (amount: number) => {
    if (isPlacingBid || currentTimeLeft <= 0) return;

    try {
      setIsPlacingBid(true);
      setLastBidTime(Date.now());
      await onPlaceBid(amount);
    } catch (error) {
      console.error('Failed to place bid:', error);
    } finally {
      setIsPlacingBid(false);
    }
  };

  if (!auctionItem) {
    return (
      <div className={`bg-gray-800 rounded-xl p-6 ${className}`}>
        <div className="text-center py-8">
          <Gavel className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-300 mb-2">No Active Auction</h3>
          <p className="text-gray-500">Waiting for the next item...</p>
        </div>
      </div>
    );
  }

  const isTimeRunningOut = currentTimeLeft <= 30000 && currentTimeLeft > 0; // Last 30 seconds
  const isTimeCritical = currentTimeLeft <= 10000 && currentTimeLeft > 0; // Last 10 seconds

  return (
    <div className={`bg-gray-800 rounded-xl overflow-hidden ${className}`}>
      {/* Current Item Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center gap-3 mb-3">
          <div className="relative">
            <img 
              src={auctionItem.image} 
              alt={auctionItem.title}
              className="w-16 h-16 object-cover rounded-lg"
            />
            <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">
              LIVE
            </div>
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-white text-lg">{auctionItem.title}</h3>
            <p className="text-gray-400 text-sm line-clamp-1">{auctionItem.description}</p>
          </div>
        </div>

        {/* Timer and Extensions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock 
              className={`${
                isTimeCritical ? 'text-red-400' : 
                isTimeRunningOut ? 'text-yellow-400' : 
                'text-cyan-400'
              }`} 
              size={20} 
            />
            <span className={`font-mono text-xl font-bold ${
              isTimeCritical ? 'text-red-400' : 
              isTimeRunningOut ? 'text-yellow-400' : 
              'text-white'
            }`}>
              {formatTime(currentTimeLeft)}
            </span>
            
            {showExtensionBadge && (
              <Badge 
                variant="secondary" 
                className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 animate-pulse"
              >
                <Zap size={12} className="mr-1" />
                Extended +10s
              </Badge>
            )}
          </div>

          <div className="text-right">
            <div className="flex items-center gap-1 text-gray-400 text-sm">
              <Users size={14} />
              <span>{auctionItem.bids.length} bids</span>
            </div>
            {softCloseExtensions > 0 && (
              <div className="text-xs text-yellow-400">
                {softCloseExtensions} extension{softCloseExtensions > 1 ? 's' : ''}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Current Price */}
      <div className="p-4 bg-gray-700/50">
        <div className="text-center">
          <div className="text-sm text-gray-400 mb-1">Current Bid</div>
          <div className="text-3xl font-bold text-green-400 mb-2">
            ${auctionItem.currentPrice.toLocaleString()}
          </div>
          <div className="text-sm text-gray-400">
            Starting bid: ${auctionItem.startingPrice.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Bidding Interface - Hidden for hosts */}
      {!isHost && currentTimeLeft > 0 && (
        <div className="p-4 space-y-4">
          {/* Preset Bid Buttons */}
          <div>
            <div className="text-sm text-gray-400 mb-2">Quick Bid</div>
            <div className="grid grid-cols-3 gap-2">
              <Button
                onClick={() => handlePresetBid(1)}
                disabled={isPlacingBid}
                className="bg-cyan-600 hover:bg-cyan-500 text-white"
                size="sm"
              >
                <DollarSign size={14} className="mr-1" />
                +$1
              </Button>
              <Button
                onClick={() => handlePresetBid(5)}
                disabled={isPlacingBid}
                className="bg-cyan-600 hover:bg-cyan-500 text-white"
                size="sm"
              >
                <DollarSign size={14} className="mr-1" />
                +$5
              </Button>
              <Button
                onClick={() => handlePresetBid(10)}
                disabled={isPlacingBid}
                className="bg-cyan-600 hover:bg-cyan-500 text-white"
                size="sm"
              >
                <DollarSign size={14} className="mr-1" />
                +$10
              </Button>
            </div>
          </div>

          {/* Max Bid */}
          <div>
            <div className="text-sm text-gray-400 mb-2">Max Bid</div>
            <div className="flex gap-2">
              <Input
                type="number"
                value={maxBid}
                onChange={(e) => setMaxBid(e.target.value)}
                placeholder={`Min $${getMinimumBid()}`}
                className="flex-1 bg-gray-700 border-gray-600 text-white"
                min={getMinimumBid()}
                step="1"
              />
              <Button
                onClick={handleMaxBid}
                disabled={isPlacingBid || !maxBid || parseFloat(maxBid) < getMinimumBid()}
                className="bg-green-600 hover:bg-green-500 text-white"
              >
                Max Bid
              </Button>
            </div>
          </div>

          {/* Custom Bid */}
          <div>
            <div className="text-sm text-gray-400 mb-2">Custom Bid</div>
            <div className="flex gap-2">
              <Input
                type="number"
                value={bidAmount}
                onChange={(e) => setBidAmount(e.target.value)}
                placeholder={`Min $${getMinimumBid()}`}
                className="flex-1 bg-gray-700 border-gray-600 text-white"
                min={getMinimumBid()}
                step="1"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleCustomBid();
                  }
                }}
              />
              <Button
                onClick={handleCustomBid}
                disabled={isPlacingBid || !bidAmount || parseFloat(bidAmount) < getMinimumBid()}
                className="bg-blue-600 hover:bg-blue-500 text-white"
              >
                <Gavel size={16} className="mr-1" />
                Bid
              </Button>
            </div>
          </div>

          {/* Bid Validation */}
          <div className="text-xs text-gray-400">
            <div className="flex items-center gap-1">
              <AlertCircle size={12} />
              <span>Minimum bid: ${getMinimumBid().toLocaleString()}</span>
            </div>
            {isTimeRunningOut && (
              <div className="flex items-center gap-1 text-yellow-400 mt-1">
                <Zap size={12} />
                <span>Bidding with ≤10s extends auction by 10 seconds</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Host Notice */}
      {isHost && (
        <div className="p-4 bg-yellow-500/10 border-t border-yellow-500/20">
          <div className="flex items-center gap-2 text-yellow-400">
            <AlertCircle size={16} />
            <span className="text-sm">You cannot bid on your own auction</span>
          </div>
        </div>
      )}

      {/* Auction Ended */}
      {currentTimeLeft <= 0 && (
        <div className="p-4 bg-red-500/10 border-t border-red-500/20">
          <div className="text-center">
            <div className="text-red-400 font-bold mb-2">Auction Ended</div>
            <div className="text-gray-300">
              Winning bid: <span className="text-green-400 font-bold">${auctionItem.currentPrice.toLocaleString()}</span>
            </div>
            {auctionItem.bids.length > 0 && (
              <div className="text-sm text-gray-400 mt-1">
                Winner: {auctionItem.bids[auctionItem.bids.length - 1]?.bidder}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Recent Bids */}
      {auctionItem.bids.length > 0 && (
        <div className="p-4 border-t border-gray-700">
          <div className="text-sm text-gray-400 mb-2">Recent Bids</div>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {auctionItem.bids.slice(-3).reverse().map((bid) => (
              <div key={bid.id} className="flex items-center justify-between text-sm">
                <span className="text-gray-300">{bid.bidder}</span>
                <span className="text-green-400 font-medium">${bid.amount.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}