import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Helper function to validate auth token
const validateAuth = async (authHeader: string | undefined) => {
  if (!authHeader) {
    return { error: 'Authorization header missing', user: null };
  }

  const token = authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : authHeader;
  
  if (!token || token === 'undefined' || token === 'null') {
    return { error: 'Invalid token format', user: null };
  }

  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);
    
    if (error || !user) {
      return { error: 'Invalid or expired token', user: null };
    }
    
    return { error: null, user };
  } catch (error) {
    return { error: 'Token validation failed', user: null };
  }
};

// Get user's shipping addresses
app.get('/shipping/addresses', async (c) => {
  try {
    console.log('📍 Get shipping addresses request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for shipping addresses:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for shipping addresses:', user.id);
    
    // Get addresses from KV store
    const addressesKey = `shipping_addresses:${user.id}`;
    const addresses = await kv.get(addressesKey) || [];
    
    console.log('📦 Retrieved addresses for user:', addresses.length);
    
    return c.json({
      success: true,
      addresses: addresses.sort((a, b) => {
        // Default address first, then by creation date
        if (a.isDefault && !b.isDefault) return -1;
        if (!a.isDefault && b.isDefault) return 1;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      })
    });
    
  } catch (error) {
    console.error('💥 Get shipping addresses error:', error);
    return c.json({ error: 'Failed to get shipping addresses' }, 500);
  }
});

// Add new shipping address
app.post('/shipping/addresses', async (c) => {
  try {
    console.log('📍 Add shipping address request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for add shipping address:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for add shipping address:', user.id);
    
    const addressData = await c.req.json();
    
    // Validate required fields
    if (!addressData.name || !addressData.streetAddress || !addressData.city || 
        !addressData.state || !addressData.zipCode || !addressData.country) {
      return c.json({ error: 'Missing required address fields' }, 400);
    }
    
    // Get existing addresses
    const addressesKey = `shipping_addresses:${user.id}`;
    const existingAddresses = await kv.get(addressesKey) || [];
    
    // Create new address
    const newAddress = {
      id: `addr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...addressData,
      userId: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // If this is the first address or marked as default, make it default
    if (existingAddresses.length === 0 || addressData.isDefault) {
      // Remove default from other addresses if setting this as default
      existingAddresses.forEach(addr => addr.isDefault = false);
      newAddress.isDefault = true;
    }
    
    // Add to addresses list
    const updatedAddresses = [...existingAddresses, newAddress];
    await kv.set(addressesKey, updatedAddresses);
    
    console.log('✅ Shipping address added successfully:', newAddress.id);
    
    return c.json({
      success: true,
      address: newAddress,
      message: 'Shipping address added successfully'
    });
    
  } catch (error) {
    console.error('💥 Add shipping address error:', error);
    return c.json({ error: 'Failed to add shipping address' }, 500);
  }
});

// Update shipping address
app.put('/shipping/addresses/:addressId', async (c) => {
  try {
    const addressId = c.req.param('addressId');
    console.log('📍 Update shipping address request received:', addressId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for update shipping address:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for update shipping address:', user.id);
    
    const addressData = await c.req.json();
    
    // Get existing addresses
    const addressesKey = `shipping_addresses:${user.id}`;
    const existingAddresses = await kv.get(addressesKey) || [];
    
    // Find address to update
    const addressIndex = existingAddresses.findIndex(addr => addr.id === addressId && addr.userId === user.id);
    
    if (addressIndex === -1) {
      return c.json({ error: 'Address not found' }, 404);
    }
    
    // Update address
    const updatedAddress = {
      ...existingAddresses[addressIndex],
      ...addressData,
      updatedAt: new Date().toISOString()
    };
    
    // If setting as default, remove default from other addresses
    if (addressData.isDefault) {
      existingAddresses.forEach((addr, index) => {
        if (index !== addressIndex) {
          addr.isDefault = false;
        }
      });
    }
    
    existingAddresses[addressIndex] = updatedAddress;
    await kv.set(addressesKey, existingAddresses);
    
    console.log('✅ Shipping address updated successfully:', addressId);
    
    return c.json({
      success: true,
      address: updatedAddress,
      message: 'Shipping address updated successfully'
    });
    
  } catch (error) {
    console.error('💥 Update shipping address error:', error);
    return c.json({ error: 'Failed to update shipping address' }, 500);
  }
});

// Delete shipping address
app.delete('/shipping/addresses/:addressId', async (c) => {
  try {
    const addressId = c.req.param('addressId');
    console.log('📍 Delete shipping address request received:', addressId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for delete shipping address:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for delete shipping address:', user.id);
    
    // Get existing addresses
    const addressesKey = `shipping_addresses:${user.id}`;
    const existingAddresses = await kv.get(addressesKey) || [];
    
    // Find address to delete
    const addressToDelete = existingAddresses.find(addr => addr.id === addressId && addr.userId === user.id);
    
    if (!addressToDelete) {
      return c.json({ error: 'Address not found' }, 404);
    }
    
    // Remove address from list
    const updatedAddresses = existingAddresses.filter(addr => addr.id !== addressId);
    
    // If deleted address was default and there are other addresses, make the first one default
    if (addressToDelete.isDefault && updatedAddresses.length > 0) {
      updatedAddresses[0].isDefault = true;
    }
    
    await kv.set(addressesKey, updatedAddresses);
    
    console.log('✅ Shipping address deleted successfully:', addressId);
    
    return c.json({
      success: true,
      message: 'Shipping address deleted successfully'
    });
    
  } catch (error) {
    console.error('💥 Delete shipping address error:', error);
    return c.json({ error: 'Failed to delete shipping address' }, 500);
  }
});

// Set address as default
app.post('/shipping/addresses/:addressId/default', async (c) => {
  try {
    const addressId = c.req.param('addressId');
    console.log('📍 Set default shipping address request received:', addressId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for set default shipping address:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for set default shipping address:', user.id);
    
    // Get existing addresses
    const addressesKey = `shipping_addresses:${user.id}`;
    const existingAddresses = await kv.get(addressesKey) || [];
    
    // Find address to set as default
    const addressIndex = existingAddresses.findIndex(addr => addr.id === addressId && addr.userId === user.id);
    
    if (addressIndex === -1) {
      return c.json({ error: 'Address not found' }, 404);
    }
    
    // Remove default from all addresses, then set the target as default
    existingAddresses.forEach((addr, index) => {
      addr.isDefault = index === addressIndex;
    });
    
    await kv.set(addressesKey, existingAddresses);
    
    console.log('✅ Default shipping address set successfully:', addressId);
    
    return c.json({
      success: true,
      message: 'Default shipping address updated successfully'
    });
    
  } catch (error) {
    console.error('💥 Set default shipping address error:', error);
    return c.json({ error: 'Failed to set default shipping address' }, 500);
  }
});

// Get buyer's shipping address for a specific order (seller access)
app.get('/shipping/order-address/:orderId', async (c) => {
  try {
    const orderId = c.req.param('orderId');
    console.log('📍 Get buyer shipping address for order request received:', orderId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for get buyer shipping address:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for get buyer shipping address:', user.id);
    
    // Get order details to verify this user is the seller
    const order = await kv.get(`order:${orderId}`);
    
    if (!order) {
      return c.json({ error: 'Order not found' }, 404);
    }
    
    // Verify the user is the seller for this order
    if (order.sellerId !== user.id) {
      return c.json({ error: 'Unauthorized - you are not the seller for this order' }, 403);
    }
    
    // Verify the order has been paid
    if (order.status !== 'paid' && order.status !== 'completed') {
      return c.json({ error: 'Shipping address only available after payment' }, 403);
    }
    
    // Get buyer's shipping address
    const buyerAddresses = await kv.get(`shipping_addresses:${order.buyerId}`) || [];
    
    // Get the address used for this order (usually the default one at time of purchase)
    let shippingAddress = buyerAddresses.find(addr => addr.id === order.shippingAddressId);
    
    // If no specific address ID stored, use the default address
    if (!shippingAddress) {
      shippingAddress = buyerAddresses.find(addr => addr.isDefault);
    }
    
    if (!shippingAddress) {
      return c.json({ error: 'No shipping address found for this order' }, 404);
    }
    
    // Remove sensitive information and add order context
    const orderShippingAddress = {
      ...shippingAddress,
      orderId: orderId,
      buyerName: order.buyerName || shippingAddress.name
    };
    
    console.log('✅ Buyer shipping address retrieved for seller:', orderId);
    
    return c.json({
      success: true,
      address: orderShippingAddress,
      order: {
        id: orderId,
        itemName: order.itemName,
        amount: order.amount,
        status: order.status,
        createdAt: order.createdAt
      }
    });
    
  } catch (error) {
    console.error('💥 Get buyer shipping address error:', error);
    return c.json({ error: 'Failed to get buyer shipping address' }, 500);
  }
});

// Share shipping address when order is paid
app.post('/shipping/share-address/:orderId', async (c) => {
  try {
    const orderId = c.req.param('orderId');
    console.log('📍 Share shipping address for paid order request received:', orderId);
    
    const { shippingAddressId } = await c.req.json();
    
    // Get order details
    const order = await kv.get(`order:${orderId}`);
    
    if (!order) {
      return c.json({ error: 'Order not found' }, 404);
    }
    
    // Update order with shipping address ID
    const updatedOrder = {
      ...order,
      shippingAddressId: shippingAddressId,
      shippingAddressSharedAt: new Date().toISOString()
    };
    
    await kv.set(`order:${orderId}`, updatedOrder);
    
    // Create notification for seller about shipping
    const sellerNotification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      userId: order.sellerId,
      type: 'shipping_address_available',
      title: 'Shipping Address Available',
      message: `Buyer's shipping address is now available for order ${orderId}. You can now ship the item.`,
      read: false,
      createdAt: new Date().toISOString(),
      metadata: {
        orderId: orderId,
        itemName: order.itemName
      }
    };
    
    // Add to seller's notifications
    const sellerNotifications = await kv.get(`notifications:${order.sellerId}`) || [];
    sellerNotifications.push(sellerNotification);
    await kv.set(`notifications:${order.sellerId}`, sellerNotifications);
    
    console.log('✅ Shipping address shared with seller for order:', orderId);
    
    return c.json({
      success: true,
      message: 'Shipping address shared with seller'
    });
    
  } catch (error) {
    console.error('💥 Share shipping address error:', error);
    return c.json({ error: 'Failed to share shipping address' }, 500);
  }
});

export default app;