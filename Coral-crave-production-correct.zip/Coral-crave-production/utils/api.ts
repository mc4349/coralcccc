/**
 * Safe API utility functions for Coral Crave
 * Prevents localhost calls and handles errors gracefully
 */

import { projectId, publicAnonKey } from './supabase/info';

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8`;

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: any;
  requireAuth?: boolean;
}

/**
 * Safe fetch wrapper that prevents localhost calls and handles errors
 */
export async function safeFetch(endpoint: string, options: ApiOptions = {}) {
  // Prevent any localhost calls
  if (endpoint.includes('localhost') || endpoint.includes('127.0.0.1')) {
    console.warn('Blocked localhost API call:', endpoint);
    throw new Error('Localhost API calls are not allowed in production');
  }

  const {
    method = 'GET',
    headers = {},
    body,
    requireAuth = false
  } = options;

  // Build full URL
  const url = endpoint.startsWith('http') ? endpoint : `${BASE_URL}${endpoint}`;

  // Prepare headers
  const requestHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${publicAnonKey}`,
    ...headers
  };

  // Add user token if auth is required
  if (requireAuth && typeof window !== 'undefined') {
    try {
      const { data: { session } } = await window.supabase.auth.getSession();
      if (session?.access_token) {
        requestHeaders['Authorization'] = `Bearer ${session.access_token}`;
      }
    } catch (error) {
      console.warn('Could not get user session for authenticated request');
    }
  }

  const requestOptions: RequestInit = {
    method,
    headers: requestHeaders,
  };

  if (body && method !== 'GET') {
    requestOptions.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(url, requestOptions);
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API Error ${response.status}: ${errorText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
}

/**
 * API endpoints for Coral Crave
 */
export const api = {
  // Auth endpoints
  signup: (data: { email: string; password: string; name: string }) =>
    safeFetch('/signup', { method: 'POST', body: data }),
  
  profile: () =>
    safeFetch('/profile', { requireAuth: true }),

  // Agora endpoints
  getAgoraToken: (data: { channelName: string; role: string; uid?: string }) => {
    // Ensure UID is numeric if provided
    const requestData = {
      ...data,
      uid: data.uid ? parseInt(data.uid, 10) || Math.floor(Math.random() * 1000000) : Math.floor(Math.random() * 1000000)
    };
    return safeFetch('/agora/token', { method: 'POST', body: requestData });
  }, 

  // Stream endpoints
  startStream: (data: { title: string; description: string; category?: string }) =>
    safeFetch('/streams/start', { method: 'POST', body: data, requireAuth: true }),
  
  getStreams: () =>
    safeFetch('/streams'),

  // Chat endpoints
  getChatMessages: (streamId: string) =>
    safeFetch(`/chat/${streamId}`),

  // Bidding endpoints
  placeBid: (data: { itemId: string; amount: number }) =>
    safeFetch('/bid', { method: 'POST', body: data, requireAuth: true }),
};

export default api;