import React, { useState } from 'react';
import { X, Mail, Lock, User, Eye, EyeOff } from 'lucide-react';
import { supabase } from '../utils/supabase/client';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface AuthModalProps {
  onClose: () => void;
}

export function AuthModal({ onClose }: AuthModalProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: ''
  });

  // Check if we're in an embedded environment
  const isEmbedded = window.location.href.includes('figmaiframepreview.figma.site') || window !== window.top;
  
  React.useEffect(() => {
    if (isEmbedded) {
      console.log('🌊 Coral Crave detected embedded environment - Google OAuth disabled for security');
    }
  }, [isEmbedded]);

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError('');

    try {
      console.log('Attempting Google sign-in...');
      console.log('Current URL:', window.location.href);
      
      // Check if we're in an embedded environment (like Figma)
      const currentUrl = window.location.href;
      const isEmbeddedEnvironment = currentUrl.includes('figmaiframepreview.figma.site') || 
                                   window !== window.top; // Check if we're in an iframe
      
      if (isEmbeddedEnvironment) {
        // In embedded environments, Google OAuth doesn't work due to iframe restrictions
        setError('Google Sign-in is not available in embedded environments due to security restrictions. Please use email/password authentication or open this app in a new browser tab.');
        console.warn('Google OAuth blocked in embedded environment');
        return;
      }
      
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
          skipBrowserRedirect: false
        }
      });

      console.log('Google OAuth response:', { data, error });

      if (error) {
        console.error('OAuth error details:', error);
        throw error;
      }
      
      // The page will redirect to Google OAuth, so no need to close modal here
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to sign in with Google';
      setError(`Google OAuth Error: ${errorMessage}`);
      console.error('Google sign in error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setLoading(true);
    setError('');

    try {
      console.log('🐠 Starting demo login process...');
      
      // First, check if the server is reachable
      try {
        console.log('🔍 Checking server health...');
        const healthResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/health`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        });
        
        if (!healthResponse.ok) {
          throw new Error('Server health check failed');
        }
        
        const healthData = await healthResponse.json();
        console.log('✅ Server is healthy:', healthData);
      } catch (healthError) {
        console.warn('⚠️ Server health check failed, but continuing with demo login...', healthError);
      }
      
      // Try to sign in with demo account first
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email: 'demo@coralcrave.com',
        password: 'demo123456'
      });

      if (signInError) {
        console.log('Demo account does not exist yet, creating...');
        console.log('Sign in error:', signInError.message);
        
        // If demo account doesn't exist, create it
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/signup`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            email: 'demo@coralcrave.com',
            password: 'demo123456',
            name: 'Demo Seller'
          })
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error('Failed to create demo account:', errorText);
          throw new Error(`Failed to create demo account: ${errorText}`);
        }

        const createResult = await response.json();
        console.log('✅ Demo account created:', createResult);

        // Wait a moment for the account to be fully created
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Now sign in with the newly created demo account
        const { data: newSignInData, error: newSignInError } = await supabase.auth.signInWithPassword({
          email: 'demo@coralcrave.com',
          password: 'demo123456'
        });

        if (newSignInError) {
          console.error('Failed to sign in with new demo account:', newSignInError);
          throw new Error(`Failed to sign in after creating demo account: ${newSignInError.message}`);
        }

        console.log('✅ Demo login successful with new account:', newSignInData.user?.email);
      } else {
        console.log('✅ Demo login successful with existing account:', signInData.user?.email);
      }

      // Close the modal after successful login
      onClose();
    } catch (err: any) {
      console.error('Demo login error:', err);
      const errorMessage = err.message || 'Failed to sign in with demo account. Please try again.';
      setError(`Demo Login Error: ${errorMessage}`);
    } finally {
      setLoading(false);
    }
  };

  const handleBuyerDemoLogin = async () => {
    setLoading(true);
    setError('');

    try {
      console.log('🛒 Starting buyer demo login process...');
      
      // Try to sign in with buyer demo account first
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email: 'buyer@coralcrave.com',
        password: 'buyer123456'
      });

      if (signInError) {
        console.log('Buyer demo account does not exist yet, creating...');
        console.log('Sign in error:', signInError.message);
        
        // If buyer demo account doesn't exist, create it
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/signup`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            email: 'buyer@coralcrave.com',
            password: 'buyer123456',
            name: 'Demo Buyer'
          })
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error('Failed to create buyer demo account:', errorText);
          throw new Error(`Failed to create buyer demo account: ${errorText}`);
        }

        const createResult = await response.json();
        console.log('✅ Buyer demo account created:', createResult);

        // Wait a moment for the account to be fully created
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Now sign in with the newly created buyer demo account
        const { data: newSignInData, error: newSignInError } = await supabase.auth.signInWithPassword({
          email: 'buyer@coralcrave.com',
          password: 'buyer123456'
        });

        if (newSignInError) {
          console.error('Failed to sign in with new buyer demo account:', newSignInError);
          throw new Error(`Failed to sign in after creating buyer demo account: ${newSignInError.message}`);
        }

        console.log('✅ Buyer demo login successful with new account:', newSignInData.user?.email);
      } else {
        console.log('✅ Buyer demo login successful with existing account:', signInData.user?.email);
      }

      // Close the modal after successful login
      onClose();
    } catch (err: any) {
      console.error('Buyer demo login error:', err);
      const errorMessage = err.message || 'Failed to sign in with buyer demo account. Please try again.';
      setError(`Buyer Demo Login Error: ${errorMessage}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isSignUp) {
        // Sign up through server endpoint
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/signup`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            email: formData.email,
            password: formData.password,
            name: formData.name
          })
        });

        if (!response.ok) {
          const errorData = await response.text();
          throw new Error(errorData || 'Failed to create account');
        }

        // After successful signup, sign in
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password
        });

        if (signInError) throw signInError;
      } else {
        // Sign in
        const { error } = await supabase.auth.signInWithPassword({
          email: formData.email,
          password: formData.password
        });

        if (error) throw error;
      }

      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred');
      console.error('Auth error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">
            {isSignUp ? 'Create Account' : 'Sign In'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Google Sign In Button */}
        <button
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full bg-white text-gray-900 py-3 rounded-lg hover:bg-gray-100 transition-colors mb-4 flex items-center justify-center gap-3 disabled:opacity-50"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          {loading ? 'Signing in...' : 'Continue with Google'}
        </button>

        {/* Demo Login Buttons - Perfect for Figma Environment */}
        <div className="space-y-2 mb-4">
          <button
            onClick={handleDemoLogin}
            disabled={loading}
            className="w-full bg-gradient-to-r from-cyan-500 to-teal-500 text-white py-3 rounded-lg hover:from-cyan-400 hover:to-teal-400 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
          >
            <span className="text-lg">🐠</span>
            {loading ? 'Signing in...' : 'Demo Seller Account'}
          </button>
          
          <button
            onClick={handleBuyerDemoLogin}
            disabled={loading}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 rounded-lg hover:from-green-400 hover:to-emerald-400 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
          >
            <span className="text-lg">🛒</span>
            {loading ? 'Signing in...' : 'Demo Buyer Account'}
          </button>
        </div>

        <div className="flex items-center my-4">
          <div className="flex-1 border-t border-gray-600"></div>
          <span className="px-4 text-gray-400 text-sm">or create your own</span>
          <div className="flex-1 border-t border-gray-600"></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div>
              <label className="block text-sm text-gray-300 mb-2">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-gray-700 text-white pl-10 pr-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none transition-colors"
                  placeholder="Enter your full name"
                  required={isSignUp}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm text-gray-300 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full bg-gray-700 text-white pl-10 pr-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none transition-colors"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-300 mb-2">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full bg-gray-700 text-white pl-10 pr-12 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none transition-colors"
                placeholder="Enter your password"
                required
                minLength={6}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-gray-400 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-red-500 bg-opacity-20 border border-red-500 rounded-lg p-3">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-cyan-500 text-white py-3 rounded-lg hover:bg-cyan-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Please wait...' : (isSignUp ? 'Create Account' : 'Sign In')}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-400">
            {isSignUp ? 'Already have an account?' : "Don't have an account?"}
          </p>
          <button
            onClick={() => {
              setIsSignUp(!isSignUp);
              setError('');
              setFormData({ email: '', password: '', name: '' });
            }}
            className="text-cyan-400 hover:text-cyan-300 transition-colors mt-1"
          >
            {isSignUp ? 'Sign In' : 'Create Account'}
          </button>
        </div>

        {/* Environment Notice */}
        {(window.location.href.includes('figmaiframepreview.figma.site') || window !== window.top) && (
          <div className="mt-4 p-3 bg-blue-500 bg-opacity-20 border border-blue-500 rounded-lg">
            <p className="text-blue-400 text-xs">
              💡 <strong>Figma Preview Environment:</strong> Google OAuth is disabled for security. Use the Demo Account or email/password authentication instead.
            </p>
          </div>
        )}

        {/* Status Notice */}
        {loading && (
          <div className="mt-4 p-3 bg-cyan-500 bg-opacity-20 border border-cyan-500 rounded-lg">
            <p className="text-cyan-400 text-xs">
              {error.includes('embedded environment') ? 'Processing authentication...' : 'Redirecting to Google for sign-in...'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}