import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info';

// Global singleton to prevent multiple GoTrueClient instances
let _supabaseClient: ReturnType<typeof createClient> | null = null;

// Prevent multiple instances warning
if (typeof window !== 'undefined') {
  // Check if client already exists in window
  if ((window as any)._coralCraveSupabaseClient) {
    _supabaseClient = (window as any)._coralCraveSupabaseClient;
  }
}

export function getSupabaseClient() {
  // Return existing client if already created
  if (_supabaseClient) {
    return _supabaseClient;
  }

  // Create new client with proper configuration
  _supabaseClient = createClient(
    `https://${projectId}.supabase.co`,
    publicAnonKey,
    {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        storage: typeof window !== 'undefined' ? window.localStorage : undefined,
        storageKey: 'coral-crave-auth', // Unique storage key to avoid conflicts
        flowType: 'pkce'
      },
      global: {
        headers: {
          'X-Client-Info': 'coral-crave-app'
        }
      }
    }
  );

  // Store in window to prevent duplicates
  if (typeof window !== 'undefined') {
    (window as any)._coralCraveSupabaseClient = _supabaseClient;
  }

  return _supabaseClient;
}

// Export the singleton instance
export const supabase = getSupabaseClient();